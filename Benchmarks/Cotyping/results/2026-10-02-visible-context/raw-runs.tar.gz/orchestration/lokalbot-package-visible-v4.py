from pathlib import Path
import datetime,hashlib,json,re,shutil,tarfile
out=Path('Benchmarks/Cotyping/results/2026-10-02-visible-context')
raw=Path('/private/tmp/lokalbot-visible-runs-20261002')
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
frozen=json.loads((out/'source-freeze.json').read_text())
assert all(digest(p)==h for p,h in frozen['files'].items())
binary=json.loads((out/'finalist-freeze.json').read_text())
assert digest(binary['executable'])==binary['appSHA256']
assert digest(out/'source-freeze.json')==binary['sourceFreezeSHA256']
tests=json.loads(Path('/private/tmp/lokalbot-visible-v4-unit-summary.json').read_text())
assert tests['result']=='Passed' and tests['failedTests']==0 and tests['skippedTests']==0 and tests['passedTests']==183
assert 'Ran 20 tests' in Path('/private/tmp/lokalbot-visible-v4-python-tests.log').read_text()
assert Path('/private/tmp/lokalbot-visible-v4-lint-final.log').stat().st_size==0
for name,marker in [('release','** BUILD SUCCEEDED **'),('debug','** TEST BUILD SUCCEEDED **')]:
 assert marker in Path('/private/tmp/lokalbot-visible-'+name+'-v4.log').read_text()
validation={
 'debugBuild':'passed','releaseBuild':'passed',
 'unitTests':{'passed':183,'failed':0,'skipped':0,'resultBundle':'/private/tmp/lokalbot-visible-unit-v4-20261002/results.xcresult','appSHA256':digest('/private/tmp/lokalbot-visible-unit-v4-20261002/LokalBot.app/Contents/MacOS/LokalBot')},
 'pythonTests':{'passed':20,'failed':0},'lint':'passed','diffCheck':'passed','documentLinks':'passed',
 'sourceFreezeMatches':True,'frozenFileCount':len(frozen['files']),'releaseAppSHA256':binary['appSHA256'],
 'nativeVisibleContextObservationsFinal':368,'nativeSavedMemoryRegressionObservations':88,'ordinaryRegressionObservations':356,
 'promptQualifiedRegressionObservations':256,
 'tuning':{'promptFrozenBeforeFirstHeldout':True,'promptChangedAfterFirstHeldout':False,'retrievalChangedAfterOriginalHeldout':True,'originalSetUsedAsRegressionAfterRetrievalChange':True,'supplementFrozenBeforeInference':True,'supplementUsedForTuning':False},
 'initialIssues':[
  {'kind':'unit test timeout','test':'testCredentialSnippetsOmittedAndPromptMarkersCannotLeak','resolution':'Added sensitive-label filtering for natural-language credential text; final test passes.'},
  {'kind':'development experiment startup cancellation','resolution':'Zero observations; identical experiment input completed on second attempt. Failed logs retained.'},
  {'kind':'unrelated saved-memory retrieval','candidate':'v3','case':'held-action-format','expectedMemoryIDs':[],'actualMemoryIDs':['memory-held-both-format'],'outputWasFactuallyCorrect':True,'resolution':'Visible terms can qualify source-title matches only. Body fallback uses draft/title terms. Production and replay share the selector; regression reproduces old behavior and verifies the fix. Fresh supplement had not run.'}
 ],
 'localUITestsRun':False,'liveAXCompatibilityValidated':False,'installed':False,'released':False,
 'changedTestExpectationsThisPhase':[]
}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
prior_archive=Path('/private/tmp/lokalbot-visible-v2-raw-runs-preserved.tar.gz')
prior_manifest=Path('/private/tmp/lokalbot-visible-v2-archive-manifest-preserved.json')
assert not prior_archive.exists() and not prior_manifest.exists()
shutil.copyfile(out/'raw-runs.tar.gz',prior_archive)
shutil.copyfile(out/'archive-manifest.json',prior_manifest)
assert digest(prior_archive)==json.loads(prior_manifest.read_text())['archiveSHA256']
files={}
def add(tar,path,name):
 path=Path(path)
 assert path.is_file() and not path.is_symlink() and name not in files,name
 files[name]=digest(path)
 tar.add(path,arcname=name,recursive=False)
archive=out/'raw-runs-v4.tmp.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(raw.rglob('*')):
  if p.is_file():add(tar,p,'runs/'+str(p.relative_to(raw)))
 for p in sorted(Path('/private/tmp').glob('lokalbot-visible-*.log')):
  add(tar,p,'validation/logs/'+p.name)
 for stage in sorted(Path('/private/tmp').glob('lokalbot-visible-unit*')):
  for p in sorted(stage.iterdir()):
   if p.is_file():add(tar,p,'validation/'+stage.name+'/'+p.name)
 add(tar,'/private/tmp/lokalbot-visible-v4-unit-summary.json','validation/unit-summary.json')
 for p in sorted(Path('/private/tmp').glob('lokalbot-*visible*.py')):
  add(tar,p,'orchestration/'+p.name)
 for p in sorted(out.glob('*.json')):
  if p.name!='archive-manifest.json':add(tar,p,'metadata/'+p.name)
 for p in sorted(frozen['files']):add(tar,p,'final-frozen-files/'+p)
 for p in ['DEVELOPMENT.md','PRIVACY.md','Benchmarks/Cotyping/README.md',str(out/'REPORT.md')]:add(tar,p,'final-documents/'+p)
 add(tar,prior_archive,'history/prompt-qualified-raw-runs.tar.gz')
 add(tar,prior_manifest,'history/prompt-qualified-archive-manifest.json')
with tarfile.open(archive,'r:gz') as tar:
 seen=set()
 for member in tar:
  data=tar.extractfile(member).read()
  assert hashlib.sha256(data).hexdigest()==files[member.name]
  seen.add(member.name)
 assert seen==set(files)
archive.replace(out/'raw-runs.tar.gz')
(out/'archive-manifest.json').write_text(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveSHA256':digest(out/'raw-runs.tar.gz'),'finalAppSHA256':binary['appSHA256'],'files':files},indent=2)+'\n')
print('Verified archive:',len(files),'files,', (out/'raw-runs.tar.gz').stat().st_size,'bytes')
print('Final validation:',tests['passedTests'],'Swift tests; 20 Python tests; 812 final native observations')
