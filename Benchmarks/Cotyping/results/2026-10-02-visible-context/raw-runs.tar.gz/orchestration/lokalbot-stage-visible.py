from pathlib import Path
import subprocess,plistlib,uuid,json,hashlib,datetime
out=Path('Benchmarks/Cotyping/results/2026-10-02-visible-context')
freeze=json.loads((out/'source-freeze.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in freeze['files'].items())
release=Path('/private/tmp/lokalbot-visible-qualified-20261002');release.mkdir(exist_ok=True)
assert '** BUILD SUCCEEDED **' in Path('/private/tmp/lokalbot-visible-release-v2.log').read_text()
subprocess.run(['ditto','--norsrc','--noextattr','.build/XcodeDerivedData/Build/Products/Release/LokalBot.app',str(release/'LokalBot.app')],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-','--timestamp=none',str(release/'LokalBot.app')],check=True)
app=release/'LokalBot.app/Contents/MacOS/LokalBot'
(out/'finalist-freeze.json').write_text(json.dumps(dict(createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),executable=str(app),appSHA256=hashlib.sha256(app.read_bytes()).hexdigest(),sourceFreezeSHA256=hashlib.sha256((out/'source-freeze.json').read_bytes()).hexdigest(),corpusSHA256=hashlib.sha256(Path('Benchmarks/Cotyping/visible-context-cases.json').read_bytes()).hexdigest()),indent=2)+'\n')
stage=Path('/private/tmp/lokalbot-visible-unit-v2-20261002');stage.mkdir(exist_ok=True)
assert '** TEST BUILD SUCCEEDED **' in Path('/private/tmp/lokalbot-visible-debug-v2.log').read_text()
subprocess.run(['ditto','--norsrc','--noextattr','.build/XcodeDerivedData/Build/Products/Debug/LokalBot.app',str(stage/'LokalBot.app')],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-','--timestamp=none','--entitlements','/private/tmp/lokalbot-quality-unit-staged-20261002/test.entitlements',str(stage/'LokalBot.app')],check=True)
old='/private/tmp/lokalbot-gemma-default-unit-20261002';d=plistlib.loads(Path(old+'/default.xctestrun').read_bytes())
def change(x):
 if isinstance(x,str):return x.replace(old,str(stage))
 if isinstance(x,list):return [change(y) for y in x]
 if isinstance(x,dict):return {k:change(v) for k,v in x.items()}
 return x
d=change(d)
for t in d['TestConfigurations'][0]['TestTargets']:t['EnvironmentVariables']['LOKALBOT_DEFAULTS_SUITE']='me.dotenv.LokalBot.visible-tests.'+uuid.uuid4().hex
for n in ['home','storage']:(stage/n).mkdir(exist_ok=True)
(stage/'default.xctestrun').write_bytes(plistlib.dumps(d))
classes=['CotypingVisibleContextTests','CotypingCoordinatorTests','CotypingSettingsTests','CotypingPromptRendererTests','CotypingContextPromptTests','CotypingRequestBuilderTests','CotypingPrefixWindowTests','CotypingMemoryContextTests','CotypingMemoryContextProviderTests','CotypingFocusPollBackoffTests','CotypingTextNormalizerTests','ModelCatalogTests','ScreenContextPrivacyTests']
with (stage/'test.log').open('w') as log:
 subprocess.run(['xcodebuild','test-without-building','-xctestrun',str(stage/'default.xctestrun'),'-destination','platform=macOS','-parallel-testing-enabled','NO','-resultBundlePath',str(stage/'results.xcresult')]+['-only-testing:LokalBotTests/'+c for c in classes],stdout=log,stderr=log,check=True)
print('Final non-UI tests passed',flush=True)
with Path('/private/tmp/lokalbot-visible-qualification.log').open('w') as log:
 subprocess.run(['uv','run','--no-project','python','-S','/private/tmp/lokalbot-visible-qualification.py'],stdout=log,stderr=log,check=True)
print('Final model qualification and ordinary regression passed',flush=True)
