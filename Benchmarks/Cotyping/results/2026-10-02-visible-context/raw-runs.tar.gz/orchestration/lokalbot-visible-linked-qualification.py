from pathlib import Path
import json,os,subprocess,tempfile,uuid,hashlib,datetime
repo=Path('/Users/0xmithrandir/Documents/GitHub/LokalBot')
app=Path('/private/tmp/lokalbot-visible-linked-20261002/LokalBot.app/Contents/MacOS/LokalBot')
root=Path('/private/tmp/lokalbot-visible-runs-20261002/final-linked')
root.mkdir(exist_ok=True)
models={'lfm':Path('/Users/0xmithrandir/Library/Application Support/me.dotenv.LokalBot/Models/LFM2.5-1.2B-Instruct-Q4_K_M.gguf'),'gemma':Path('/Users/0xmithrandir/Library/Application Support/Cotabby/LlamaRuntime/gemma-4-E2B.i1-Q6_K.gguf')}
for split in ['development','heldout']:
 for name,model in models.items():
  output=root/(name+'-'+split+'-final')
  subprocess.run(['uv','run','--no-project','python','-S',str(repo/'Benchmarks/Cotyping/visible_context_replay.py'),'--app',str(app),'--model',str(model),'--split',split,'--output',str(output)],check=True,cwd=repo)
for split in ['development','heldout']:
 for name,model in models.items():
  output=root/(name+'-linked-'+split)
  subprocess.run(['uv','run','--no-project','python','-S',str(repo/'Benchmarks/Cotyping/visible_context_replay.py'),'--app',str(app),'--model',str(model),'--corpus',str(repo/'Benchmarks/Cotyping/visible-memory-link-cases.json'),'--split',split,'--output',str(output)],check=True,cwd=repo)
proof={}

for name,model in models.items():
 old=Path('/private/tmp/lokalbot-memory-runs-20261002')/(name+'-ordinary')
 out=root/(name+'-ordinary-final');out.mkdir(exist_ok=False)
 fixture=old/'input.json'
 with tempfile.TemporaryDirectory(prefix='lokalbot-visible-ordinary-') as d:
  t=Path(d);(t/'home').mkdir();(t/'storage').mkdir()
  env=dict(os.environ,CFFIXED_USER_HOME=str(t/'home'),LOKALBOT_STORAGE_ROOT=str(t/'storage'),LOKALBOT_DEFAULTS_SUITE='me.dotenv.LokalBot.visible-ordinary.'+uuid.uuid4().hex)
  with (out/'observations.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
   subprocess.run([str(app),'--cotyping-replay',str(fixture),'--model-path',str(model)],stdout=stdout,stderr=stderr,env=env,check=True,timeout=900)
 previous=list(map(json.loads,(old/'observations.jsonl').read_text().splitlines()))
 current=list(map(json.loads,(out/'observations.jsonl').read_text().splitlines()))
 assert [r['id'] for r in previous]==[r['id'] for r in current]
 keys=['id','prompt','text','suppression','error']
 differences=[{'before':a,'after':b} for a,b in zip(previous,current) if any(a.get(k)!=b.get(k) for k in keys)]
 proof[name]={'cases':len(current),'identical':len(current)-len(differences),'differences':differences,'inputSHA256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'baselineAppSHA256':json.loads((old/'manifest.json').read_text())['appSHA256'],'appSHA256':hashlib.sha256(app.read_bytes()).hexdigest()}
 (out/'input.json').write_bytes(fixture.read_bytes())
 print(name,'ordinary:',proof[name]['identical'],'/',len(current),flush=True)
(root/'ordinary-regression-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert all(not r['differences'] for r in proof.values())
