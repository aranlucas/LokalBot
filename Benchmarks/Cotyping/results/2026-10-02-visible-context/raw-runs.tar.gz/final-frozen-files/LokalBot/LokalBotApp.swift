import SwiftUI
import Combine
import AVFoundation
import CoreGraphics
import AppKit

/// Process entry point. Parses any headless subcommand before SwiftUI exists,
/// and disables AppKit window restoration *before* SwiftUI launches when
/// starting menu-bar-only — `applicationWillFinishLaunching` runs after AppKit
/// has already read the flag, so a previously-open window would be restored
/// and force the Dock icon back on. Setting it pre-launch is the only
/// reliable point.
@main
enum LokalBotMain {
    /// Held for the process lifetime; see `LibraryInstanceLock`.
    @MainActor private static var libraryLock: LibraryInstanceLock?

    @MainActor
    static func main() {
        // Explicit synthetic replay runs before migration, AppState, permissions,
        // learning, or capture. Only the supplied fixture and model are read.
        if case .cotypingReplay(let input, let model)? = HeadlessCommand.parse(CommandLine.arguments) {
            Task { @MainActor in exit(await CotypingQualityReplay.run(input: input, model: model)) }
            RunLoop.main.run()
            return
        }
        routeStartup(
            migrate: { DataMigration.runIfNeeded() },
            launchApplication: {
                HeadlessCommand.requested = HeadlessCommand.parse(CommandLine.arguments)
                if case .agentSessions(let dayKey)? = HeadlessCommand.requested {
                    exit(CodingAgentSessionsCLI.run(dayKey: dayKey))
                }
#if DEBUG
                if case .recordCapture(_, let scenario) = HeadlessCommand.requested {
                    let recorder = CaptureTraceRecorder(scenario: scenario, origin: scenario == "real" ? .real : .scripted)
                    CaptureTraceRecorder.active = recorder
                    CaptureEnvironment.install(recorder.environment)
                }
#endif
#if LOKALBOT_TEST_HOOKS
                if UITestRuntime.isEnabled, TestHooks.backgroundHostEnabled {
                    if let path = TestHooks.backgroundTracePath,
                       let trace = try? CaptureTrace.load(from: URL(fileURLWithPath: path)) {
                        CaptureEnvironment.install(
                            ReplayCaptureEnvironment(trace: trace, start: Date(), realTimeSpeed: 1).environment)
                    }
                    if let audio = TestHooks.backgroundAudioDirectory {
                        MicRecorder.defaultInputFactory = {
                            try FileMicrophoneInput(url: audio.appendingPathComponent("mic.wav"))
                        }
                        SystemAudioRecorder.defaultTapFactory = {
                            if let tap = try? FileSystemAudioTap(url: audio.appendingPathComponent("system.wav")) {
                                return tap
                            }
                            return CoreAudioProcessTap()
                        }
                    }
                }
#endif
                if HeadlessCommand.requested == nil, !UITestRuntime.isEnabled, !UITestRuntime.isUnitTesting {
                    let root = AppDirectories.libraryRoot
                    guard let lock = LibraryInstanceLock.acquire(root: root) else {
                        lokalbotLog("another LokalBot is using \(root.path); activating it and exiting")
                        let current = ProcessInfo.processInfo.processIdentifier
                        NSRunningApplication.runningApplications(withBundleIdentifier: AppIdentifiers.bundleID)
                            .first { $0.processIdentifier != current }?
                            .activate()
                        exit(0)
                    }
                    libraryLock = lock
                }
                UserDefaults.standard.set(lokalbotLaunchesMenuBarOnly(),
                                          forKey: "ApplePersistenceIgnoreState")
                LokalBotApp.main()
            },
            launchRecovery: { outcome in
                MigrationRecoveryApp.initialOutcome = outcome
                MigrationRecoveryApp.main()
            })
    }

    /// Never construct `AppState` after an incomplete migration: its stored
    /// `StorageManager` creates the destination library and turns a transient
    /// failure into a persistent old/new conflict on the next launch.
    @discardableResult
    static func routeStartup(
        migrate: () -> DataMigration.StartupOutcome,
        launchApplication: () -> Void,
        launchRecovery: (DataMigration.StartupOutcome) -> Void
    ) -> DataMigration.StartupOutcome {
        let outcome = migrate()
        switch outcome {
        case .ready:
            launchApplication()
        case .retryRequired, .conflict:
            launchRecovery(outcome)
        }
        return outcome
    }
}

/// A minimal process mode for retained migration failures. It deliberately has
/// no `AppState`, storage, indexes, capture services, or background workers.
private struct MigrationRecoveryApp: App {
    @MainActor static var initialOutcome: DataMigration.StartupOutcome =
        .retryRequired("Migration has not completed.")

    @StateObject private var recovery: MigrationRecoveryState

    init() {
        _recovery = StateObject(wrappedValue: MigrationRecoveryState(
            outcome: Self.initialOutcome))
    }

    var body: some Scene {
        Window("LokalBot Data Recovery", id: "migration-recovery") {
            MigrationRecoveryView(recovery: recovery)
        }
        .defaultSize(width: 560, height: 360)
        .windowResizability(.contentSize)
    }
}

@MainActor
private final class MigrationRecoveryState: ObservableObject {
    @Published var outcome: DataMigration.StartupOutcome

    init(outcome: DataMigration.StartupOutcome) {
        self.outcome = outcome
    }

    func retry() {
        outcome = DataMigration.runIfNeeded()
    }

    var conflictingDirectories: [URL] {
        guard case .conflict(let conflict) = outcome else { return [] }
        return [conflict.legacyDirectory, conflict.currentDirectory]
    }
}

private struct MigrationRecoveryView: View {
    @ObservedObject var recovery: MigrationRecoveryState

    private var presentation: (title: String, detail: String, symbol: String) {
        switch recovery.outcome {
        case .ready:
            return (
                "Your library is ready",
                "Migration completed safely. Quit and reopen LokalBot to load the recovered library.",
                "checkmark.circle.fill")
        case .retryRequired(let reason):
            return (
                "LokalBot could not finish data recovery",
                reason + "\n\nYour existing library was preserved. Retry after resolving the error.",
                "exclamationmark.arrow.triangle.2.circlepath")
        case .conflict(let conflict):
            return (
                "Two LokalBot libraries need recovery",
                "LokalBot preserved both \(conflict.identity) and the current library. "
                    + "Review the folders below, then retry after keeping the library you want.\n\n"
                    + "Legacy: \(conflict.legacyDirectory.path)\nCurrent: \(conflict.currentDirectory.path)",
                "externaldrive.badge.exclamationmark")
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(alignment: .top, spacing: 16) {
                Image(systemName: presentation.symbol)
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(recovery.outcome == .ready ? .green : .orange)
                VStack(alignment: .leading, spacing: 10) {
                    Text(presentation.title)
                        .font(.scaled(.title2).weight(.semibold))
                    Text(presentation.detail)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
            }

            Spacer(minLength: 0)

            HStack {
                if !recovery.conflictingDirectories.isEmpty {
                    Button("Show Libraries in Finder") {
                        NSWorkspace.shared.activateFileViewerSelecting(
                            recovery.conflictingDirectories)
                    }
                }
                Spacer()
                if recovery.outcome == .ready {
                    Button("Quit LokalBot") {
                        NSApplication.shared.terminate(nil)
                    }
                    .keyboardShortcut(.defaultAction)
                } else {
                    Button("Quit") {
                        NSApplication.shared.terminate(nil)
                    }
                    Button("Retry Migration") {
                        recovery.retry()
                    }
                    .keyboardShortcut(.defaultAction)
                }
            }
        }
        .padding(28)
        .frame(width: 560, height: 360)
    }
}

struct LokalBotApp: App {
    @StateObject private var app: AppState
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    init() {
        let appState = AppState()
        _app = StateObject(wrappedValue: appState)
        AppDelegate.appState = appState
    }

    var body: some Scene {
        Window("LokalBot", id: "main") {
            mainWindow
        }
        .defaultSize(width: 1180, height: 740)
        .commands {
            SidebarCommands()
            AgentCommands(app: app)
            CommandMenu("Recording") {
                Button(app.isRecording ? "Stop Recording" : "Start Recording") {
                    app.isRecording
                        ? app.stopRecording()
                        : app.startRecording(context: app.recordingContext(for: app.detector.activeApp), source: "command")
                }
                .keyboardShortcut("r", modifiers: [.command, .shift])

                Divider()

                Button(
                    app.dictation.state.isRecording
                        ? "Stop & Compose Dictation"
                        : app.dictation.isStarting || app.dictation.state.isWorking
                            ? "Cancel Dictation" : "Start Dictation"
                ) {
                    app.dictation.toggle(source: "command")
                }
#if DEBUG
                Divider()

                Button("Record Capture Trace (60 s)") {
                    app.startCaptureTraceRecording()
                }
#endif
            }
            // ⌘K opens the command palette. Registered at the app level so it
            // works from anywhere; the palette window is opened via openWindow.
            CommandGroup(after: .toolbar) {
                Button("Command Palette…") {
                    WindowAccess.shared.open("palette")
                }
                .keyboardShortcut("k", modifiers: [.command])

                Button("Ask…") {
                    WindowAccess.shared.open("quick-recall")
                }
            }
            CommandGroup(before: .textEditing) {
                Button(app.navSection == .agent ? "Find in Task…" : "Find in Meeting…") {
                    if app.navSection == .agent { app.agentSessions.findRequest += 1 } else { app.requestSelectedMeetingSearch() }
                }
                .keyboardShortcut("f", modifiers: .command)
                .disabled(app.navSection != .agent && !app.canSearchSelectedMeeting)
            }
            // Keep the standard Settings shortcut inside the main workspace.
            CommandGroup(replacing: .appSettings) {
                Button("Settings…") {
                    app.openSettings()
                }
                .keyboardShortcut(",", modifiers: .command)
            }
        }

        Window("Welcome to LokalBot", id: "onboarding") {
            OnboardingView()
                .environmentObject(app)
                .appTextSizeRoot(app.settings.textSize)
        }
        .windowResizability(.contentSize)

        // The ⌘K command palette. A lightweight, keyboard-first launcher that
        // records, navigates, and opens recent meetings without the sidebar.
        Window("Command Palette", id: "palette") {
            CommandPaletteView()
                .environmentObject(app)
                .brandTinted()
                .appTextSizeRoot(app.settings.textSize)
        }
        .windowResizability(.contentSize)
        .windowStyle(.hiddenTitleBar)
        .defaultPosition(.center)

        Window("Ask", id: "quick-recall") {
            QuickRecallView()
                .environmentObject(app)
                .brandTinted()
                .appTextSizeRoot(app.settings.textSize)
        }
        .windowResizability(.contentSize)
        .windowStyle(.hiddenTitleBar)
        .defaultPosition(.center)

#if !LOKALBOT_UI_TEST_HOST
        MenuBarExtra {
            MenuBarView(dictation: app.dictation)
                .environmentObject(app)
                .brandTinted()
                .appTextSizeRoot(app.settings.textSize)
        } label: {
            MenuBarLabel(app: app, dictation: app.dictation)
        }
        .menuBarExtraStyle(.window)
#endif
    }

    private var mainWindow: some View {
        MainWindowView()
            .environmentObject(app)
            .brandTinted()
            .appTextSizeRoot(app.settings.textSize)
    }
}

/// One long-lived utility worker owns the background FTS connection. A
/// dictionary keeps only the latest pending snapshot for each meeting, while
/// the actor serializes SQLite writes across the entire queue.
actor SearchIndexWorkQueue {
    private let databaseURL: URL
    private let rootURL: URL
    private var index: SearchIndex?
    private var storage: StorageManager?
    private var pending: [Meeting.ID: Meeting] = [:]
    private var deleted: Set<Meeting.ID> = []
    private var drainTask: Task<Void, Never>?
    private var stopped = false

    init(databaseURL: URL, rootURL: URL) {
        self.databaseURL = databaseURL
        self.rootURL = rootURL
    }

    func enqueue(_ meeting: Meeting) {
        enqueue([meeting])
    }

    func enqueue(_ meetings: [Meeting]) {
        guard !stopped else { return }
        for meeting in meetings where !deleted.contains(meeting.id) {
            pending[meeting.id] = meeting
        }
        startDrainIfNeeded()
    }

    @discardableResult
    func remove(_ meetingID: Meeting.ID) -> (search: Bool, embedding: Bool) {
        deleted.insert(meetingID)
        pending.removeValue(forKey: meetingID)
        let searchClean = searchIndex.remove(meetingID)
        let embeddingClean = EmbeddingIndex.remove(
            meetingID, databaseURL: databaseURL)
        return (searchClean, embeddingClean)
    }

    /// Reopens a source folded into a merged meeting and queues its existing
    /// evidence for indexing again. The actor serializes this with any late
    /// cleanup request from the original merge.
    func restore(_ meeting: Meeting) throws -> Meeting {
        guard !stopped else { throw CancellationError() }
        let restored = try workerStorage.restoreMergedSource(meeting)
        deleted.remove(meeting.id)
        searchIndex.noteRestoration(meeting.id)
        pending[meeting.id] = restored
        startDrainIfNeeded()
        return restored
    }

    @discardableResult
    func reconcileDeletedMeetings() -> (search: Bool, embedding: Bool) {
        let searchClean = searchIndex.reconcileDeletedMeetings()
        let embeddingClean = EmbeddingIndex.reconcileDeletedMeetings(
            databaseURL: databaseURL)
        return (searchClean, embeddingClean)
    }

    func stop() {
        stopped = true
        pending.removeAll()
        drainTask?.cancel()
        drainTask = nil
    }

    /// Test/diagnostic seam: wait for the currently scheduled drain and any
    /// follow-up work that arrived while it yielded between meetings.
    func waitUntilIdle() async {
        while let drainTask {
            await drainTask.value
        }
    }

    private var searchIndex: SearchIndex {
        if let index { return index }
        let created = SearchIndex(databaseURL: databaseURL)
        index = created
        return created
    }

    private var workerStorage: StorageManager {
        if let storage { return storage }
        let created = StorageManager(rootURL: rootURL)
        storage = created
        return created
    }

    private func startDrainIfNeeded() {
        guard drainTask == nil, !pending.isEmpty, !stopped else { return }
        drainTask = Task(priority: .utility) { [weak self] in
            await self?.drain()
        }
    }

    private func drain() async {
        while !Task.isCancelled, !stopped, let (meetingID, meeting) = pending.first {
            pending.removeValue(forKey: meetingID)
            searchIndex.reindex(meeting, storage: workerStorage)
            // Let enqueues, deletions, and shutdown coalesce or cancel work
            // between meetings without allowing concurrent SQLite writers.
            await Task.yield()
        }
        drainTask = nil
        startDrainIfNeeded()
    }
}
