import Foundation

enum OutcomeEvidencePolicy {
    /// Only speaker-local preambles may precede a commitment. Keep the clause
    /// anchored so reported speech ("I said…") cannot become a new promise.
    /// Acceptance and conversation-management checks share the same prefix.
    private static let commitmentPreamble =
        #"^(?:(?:yes|yeah|yep|okay|ok|sure|right|well|so|and|then|absolutely|after this|next|also|um|uh|"#
        + #"(?:on|from) my (?:side|end)|for my part|as for me)[,!.: ]+)*"#
    private static let firstPersonUndertaking =
        #"(?:i (?:will|shall|am going to|am gonna|commit to|agree to|(?:do )?(?:plan|intend) to|am (?:planning|intending) to)"#
        + #"|i['’]m (?:going to|gonna|planning to|intending to)|i['’]ll|my next step is"#
        + #"|(?:i think )?i (?:still )?(?:have to|need to|must))"#

    /// A missing quote is compatible only with one unambiguous undertaking.
    /// Never choose the first promise from a passage containing other actors'
    /// tasks: even a verbatim quote cannot establish which task was paraphrased.
    static func resolveFromSource(
        speakerID: String?, basis: String?, source: Transcript.Segment,
        visibleText: String, roster: [String: Transcript.SpeakerDescriptor],
        addressedToUser: Bool = false, quote: String? = nil
    ) -> OutcomeAttribution {
        func reject(_ reason: OutcomeAttribution.RejectionReason) -> OutcomeAttribution {
            .init(resolution: .unresolved, speakerID: speakerID.flatMap { roster[$0] == nil ? nil : $0 },
                  basis: .unclear, rejectionReason: reason)
        }
        guard !hasCompetingActors(in: source.displayText) else { return reject(.ambiguousQuote) }
        let supplied = quote.flatMap { normalized($0).isEmpty ? nil : $0 }
        let clauses = supplied.map { [$0] } ?? canonicalClauses(visibleText)
        // With no selected quote, a second task-bearing clause makes inference
        // ambiguous even when only one of its owners passes identity checks.
        if supplied == nil, clauses.filter({ expressesUndertaking($0) || isSecondPersonRequest($0) }).count > 1 {
            return reject(.missingQuote)
        }
        var failure = resolve(speakerID: speakerID, basis: basis, quote: nil, sources: [source], roster: roster)
        var accepted: [OutcomeAttribution] = []
        for quote in clauses {
            let resolvedBasis = basis == "unclear" && isCommitment(quote) ? "commitment" : basis
            let attribution = resolve(speakerID: speakerID, basis: resolvedBasis,
                                      quote: quote, sources: [source], roster: roster,
                                      addressedToUser: addressedToUser)
            if attribution.resolution != .unresolved { accepted.append(attribution) }
            failure = attribution
        }
        if accepted.count > 1 { return reject(.ambiguousQuote) }
        return accepted.first ?? failure
    }

    static func hasCommitment(source: Transcript.Segment, visibleText: String) -> Bool {
        !hasCompetingActors(in: source.displayText)
            && canonicalClauses(visibleText).contains { isCommitment($0) && supportsCommitment($0, in: source.displayText) }
    }

    /// Independent actor clauses, including coordinated promises, are not a
    /// single ownership anchor. Purpose clauses ("so you can introduce us")
    /// are deliberately not treated as another assignment.
    static func hasCompetingActors(in raw: String) -> Bool {
        let text = normalized(raw)
        let boundary = #"(?:^|[.!?;]\s*|,\s*(?!so\b)|\b(?:and|but|while)\s+)(?:(?:and|but|then|also|so|yeah|yes)\s*,?\s*)*"#
        let actor = #"([\p{L}][\p{L}'’-]*(?:\s+[\p{L}][\p{L}'’-]*){0,2}?)"#
        let undertaking = #"(?:\s+(?:will|shall|must|should|can|have to|has to|need to|needs to|am going to|is going to|are going to|plan to|plans to|is responsible for)|['’]ll)\s+"#
        guard let regex = try? NSRegularExpression(pattern: boundary + actor + undertaking) else { return true }
        let actors = regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { match -> String? in
            guard let range = Range(match.range(at: 1), in: text) else { return nil }
            let value = String(text[range])
            return value == "i" || value.hasPrefix("i ") || value.hasPrefix("i'm") || value.hasPrefix("i’m") ? "i" : value
        }
        let hasRequest = canonicalClauses(text).contains(where: isSecondPersonRequest)
        let hasPersonalUndertaking = canonicalClauses(text).contains(where: isCommitment)
        return Set(actors + (hasRequest ? ["you"] : []) + (hasPersonalUndertaking ? ["i"] : [])).count > 1
    }

    static func isBareAcceptance(_ raw: String) -> Bool {
        normalized(raw).range(of:
            commitmentPreamble + #"i can (?:do (?:that|it)|take (?:that|it)(?: on)?|handle (?:that|it))[.! ]*$"#,
            options: .regularExpression) != nil
    }

    static func isConversationManagement(_ raw: String) -> Bool {
        normalized(raw).range(of:
            commitmentPreamble + firstPersonUndertaking
                + #" be (?:a little (?:bit )?)?(?:more specific|more clear|clearer|brief)[.! ]*$"#,
            options: .regularExpression) != nil
    }

    private static func canonicalClauses(_ text: String) -> [String] {
        let regex = try? NSRegularExpression(pattern: #"[^.!?;]+[.!?;]*"#)
        return regex?.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { match in
            guard let range = Range(match.range, in: text) else { return nil }
            let quote = String(text[range]).trimmingCharacters(in: .whitespacesAndNewlines)
            return quote.isEmpty || quote.count > 1_000 ? nil : quote
        } ?? []
    }

    /// `addressedToUser` is transcript evidence supplied by the caller: the
    /// user spoke the next turn after this request. It can make an unnamed
    /// "you" request the user's, never another participant's.
    static func resolve(
        speakerID: String?, basis: String?, quote: String?,
        sources: [Transcript.Segment], roster: [String: Transcript.SpeakerDescriptor],
        addressedToUser: Bool = false
    ) -> OutcomeAttribution {
        func reject(_ reason: OutcomeAttribution.RejectionReason) -> OutcomeAttribution {
            OutcomeAttribution(resolution: .unresolved, speakerID: speakerID.flatMap { roster[$0] == nil ? nil : $0 },
                               basis: .unclear, rejectionReason: reason)
        }
        guard let speakerID else { return reject(.missingSpeaker) }
        guard let person = roster[speakerID] else { return reject(.unknownSpeaker) }
        guard person.identity != .unresolved else { return reject(.unconfirmedIdentity) }
        guard let basis = basis.flatMap(OutcomeAttribution.Basis.init(rawValue:)),
              [.commitment, .assignment, .request].contains(basis) else { return reject(.missingBasis) }
        guard let quote, !normalized(quote).isEmpty, quote.count <= 1_000 else { return reject(.missingQuote) }
        let quoted = sources.filter { normalized($0.displayText).contains(normalized(quote)) }
        guard !quoted.isEmpty else { return reject(.quoteNotFound) }
        if basis == .commitment {
            // Identity comes from the cited voice. Conversational acceptance is
            // evidence of a commitment, never evidence that the speaker is "Me".
            guard isCommitment(quote), quoted.allSatisfy({ supportsCommitment(quote, in: $0.displayText) }) else {
                return reject(.unsupportedCommitment)
            }
            guard quoted.allSatisfy({
                Transcript.canonicalSpeakerKey($0.speaker) == speakerID
                    && $0.resolvedAttribution.identity == person.identity
                    && ![.overlappingSpeech, .suspectedEcho].contains($0.resolvedAttribution.method)
            }) else { return reject(.speakerMismatch) }
        } else {
            let names = uniqueTargetNames(for: person, roster: roster)
            let named = names.contains(where: { name in
                hasExplicitTarget(name, in: quote, basis: basis) && quoted.allSatisfy { source in
                    evidenceClause(quote, in: source.displayText).map { hasExplicitTarget(name, in: $0, basis: basis) } == true
                }
            })
            // Another participant asked "you", and the user answered next.
            let answeredByUser = addressedToUser && person.identity == .user
                && quoted.allSatisfy { source in
                    roster[Transcript.canonicalSpeakerKey(source.speaker)]?.identity == .other
                        && evidenceClause(quote, in: source.displayText).map(isSecondPersonRequest) == true
                }
            guard named || answeredByUser else {
                return reject(names.isEmpty && !addressedToUser ? .ambiguousName : .targetNotExplicit)
            }
        }
        return OutcomeAttribution(resolution: person.identity == .user ? .user : .other,
            speakerID: speakerID, basis: basis, quote: quote)
    }

    /// Accept explicit first-person plans as well as promises and acceptance,
    /// but not questions, hypothetical promises, past reports, or collective "we".
    static func isCommitment(_ raw: String) -> Bool {
        let text = normalized(raw)
        guard !isConversationManagement(text) else { return false }
        let undertaking = firstPersonUndertaking + #"\s+(?!not\b|never\b|no longer\b)\S"#
        let acceptance = #"i can (?:do (?:that|it)|take (?:that|it)(?: on)?|handle (?:that|it))\b"#
        let translated = #"(?:ja ću |ja cu |je vais |ich werde |voy a |我会|我會)"#
        guard text.range(of: commitmentPreamble + "(?:" + undertaking + "|" + acceptance + "|" + translated + ")",
                         options: .regularExpression) != nil else { return false }
        // Preserve surrounding uncertainty even when a short quote omits it.
        return text.range(of: #"\?|\b(?:if|unless|might|maybe|perhaps|cannot|can't|can’t|won't|won’t)\b"#,
                          options: .regularExpression) == nil
    }

    /// Questions, conditions, hedges, and negations. Such a statement cannot
    /// become a task merely because its wording escaped the commitment check.
    static func isQualified(_ raw: String) -> Bool {
        normalized(raw).range(of:
            #"\?|\b(?:if|unless|might|maybe|perhaps|not|never|cannot|can't|can’t|won't|won’t|don't|don’t|shouldn't|shouldn’t)\b"#,
            options: .regularExpression) != nil
    }

    /// Offers that commit without a modal verb ("I can send you the numbers
    /// tomorrow", "Leave it with me"). Like `expressesUndertaking`, this only
    /// keeps a quoted task whose stricter commitment check failed; it never
    /// establishes ownership.
    static func offersToTakeOn(_ raw: String) -> Bool {
        normalized(raw).range(of: #"\bi can (?!not\b)\w|\bleave (?:it|that|this) (?:with|to) me\b"#,
                              options: .regularExpression) != nil
    }

    /// Forward-looking wording ("we should", "I need to", "let me"). A task
    /// whose commitment claim failed is kept only when its own source still
    /// expresses an undertaking; a fragment cannot manufacture one.
    static func expressesUndertaking(_ raw: String) -> Bool {
        normalized(raw).range(of:
            #"\b(?:will|shall|going to|gonna|need to|needs to|have to|has to|got to|should|must|let me|let['’]s|let us|plan to|want to)\b|['’]ll\b"#,
            options: .regularExpression) != nil
    }

    /// A direct second-person request to one listener ("Could you send…",
    /// "You need to…"). Group addresses and hypotheticals are excluded; a
    /// polite "if you could" is still a request.
    static func isSecondPersonRequest(_ raw: String) -> Bool {
        let text = normalized(raw).replacingOccurrences(of:
            #"\bif you (?:could|can|would|don['’]t mind)\b"#, with: "could you", options: .regularExpression)
        guard text.range(of: #"\b(?:if|unless|might|perhaps)\b"#, options: .regularExpression) == nil,
              text.range(of: #"\byou (?:all|guys|both|two)\b|\b(?:everyone|everybody|anyone|anybody|someone|somebody|y['’]all)\b"#,
                         options: .regularExpression) == nil else { return false }
        let patterns = [
            #"\b(?:can|could|would|will) you (?:please |maybe |also |just )*(?!not\b)\w"#,
            #"\byou (?:need to|have to|must|should|will need to|['’]ll need to)\s+(?!not\b|never\b)\w"#,
            #"\bi(?:['’]d| would)? (?:need|want|like) you to\b"#,
            #"\bmake sure (?:that )?you\b"#,
            #"(?:^|[.!?]\s*)please (?!note\b)\w"#,
        ]
        return patterns.contains { text.range(of: $0, options: .regularExpression) != nil }
    }

    private static func supportsCommitment(_ quote: String, in source: String) -> Bool {
        evidenceClause(quote, in: source).map(isCommitment) == true
    }

    private static func evidenceClause(_ quote: String, in source: String) -> String? {
        let text = normalized(source)
        guard let match = text.range(of: normalized(quote)) else { return nil }
        let prefix = text[..<match.lowerBound]
        let boundary = prefix.lastIndex(where: { ".!?;".contains($0) })
        let start = boundary.map { text.index(after: $0) } ?? text.startIndex
        let suffix = text[match.upperBound...]
        let quoteEndsClause = ".!?;".contains(text[text.index(before: match.upperBound)])
        let end = quoteEndsClause ? match.upperBound
            : suffix.firstIndex(where: { ".!?;".contains($0) }).map { text.index(after: $0) } ?? text.endIndex
        return String(text[start..<end])
    }

    private static func uniqueTargetNames(for person: Transcript.SpeakerDescriptor,
                                          roster: [String: Transcript.SpeakerDescriptor]) -> [String] {
        let name = normalized(person.name)
        guard !["me", "you", "them", "local speaker", "speaker unclear"].contains(name),
              name.range(of: #"^(?:them|local|speaker)(?:\s+\d+|\s+unclear)?$"#, options: .regularExpression) == nil else { return [] }
        // First names are usable only when they identify one named speaker.
        let candidates = [name, name.split(separator: " ").first.map(String.init)].compactMap { $0 }
        return Array(Set(candidates)).filter { candidate in
            roster.values.filter { other in
                let otherName = normalized(other.name)
                return otherName == candidate || otherName.split(separator: " ").first.map(String.init) == candidate
            }.count == 1
        }
    }

    private static func hasExplicitTarget(_ name: String, in quote: String, basis: OutcomeAttribution.Basis) -> Bool {
        let subject = NSRegularExpression.escapedPattern(for: name)
        let text = normalized(quote)
        guard text.range(of: #"\b(?:if|unless|might|maybe|perhaps)\b"#, options: .regularExpression) == nil else { return false }
        let start = #"(?:^|[.!?]\s*)(?:(?:okay|ok|so|and|then|yes|yeah)[, ]+)*"#
        let patterns: [String]
        if basis == .request {
            patterns = [
                start + subject + #"[, :]+(?:please\b|(?:can|could|would|will) you\b)"#,
                start + #"(?:can|could|would|will) you,\s*"# + subject + #"[, :]"#,
                start + #"(?:please|can|could|would|will)\s+"# + subject + #"\s+(?!not\b)\w"#,
            ]
        } else {
            patterns = [start + subject + #"\s+(?:will\s+(?!not\b)|is responsible for\s+|owns\s+|to\s+)\w"#]
        }
        return patterns.contains { text.range(of: $0, options: .regularExpression) != nil }
    }

    private static func normalized(_ text: String) -> String {
        text.replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
}
