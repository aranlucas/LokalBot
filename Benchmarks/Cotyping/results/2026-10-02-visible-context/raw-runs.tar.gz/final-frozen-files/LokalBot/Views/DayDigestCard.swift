import SwiftUI

/// One digest presentation for Today and Timeline, with the same generation,
/// export, freshness and inference behavior in each destination.
struct DayDigestCard: View {
    @EnvironmentObject private var app: AppState
    @ObservedObject var model: CaptureModel
    var yesterday: DreamReport?
    let identifier: String
    var showsControls = true
    var mode: DayDigestView.Mode = .timeline

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if showsControls { DayDigestControls(model: model, identifier: identifier) }
            if let digest = model.digest {
                DayDigestView(digest, mode: mode)
                    .accessibilityElement(children: .contain)
                    .accessibilityIdentifier("\(identifier).dayDigest.text")
            } else {
                Text("Your digest brings together this day's meetings and captured activity.")
                    .workspaceTextRole(.supporting)
            }
            if model.digestUpdatedAt != nil || model.digestIsStale {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    if let updated = model.digestUpdatedAt {
                        Text("Updated " + updated.formatted(date: .omitted, time: .shortened))
                    }
                    if model.digestIsStale {
                        Text("New activity available · Update digest to include it")
                            .accessibilityIdentifier("\(identifier).dayDigest.stale")
                    }
                }
                .font(AppFont.scaled(.callout)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            }
            if let yesterday {
                Divider()
                YesterdayDigestLine(report: yesterday, day: model.day)
            }
            if let error = model.digestError {
                Label(error, systemImage: "exclamationmark.triangle").workspaceTextRole(.warning)
            }
        }
    }
}

struct DayDigestControls: View {
    @EnvironmentObject private var app: AppState
    @ObservedObject var model: CaptureModel
    let identifier: String
    var showsAsk = true

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { if showsAsk { ask }; generate; actions }
            VStack(alignment: .leading, spacing: 8) {
                if showsAsk { ask }
                HStack(spacing: 8) { generate; actions }
            }
        }
        .controlSize(.small)
    }

    private var ask: some View {
        Button { app.openAsk(dayScope: model.day) } label: {
            Label("Ask About This Day", systemImage: "sparkle.magnifyingglass")
        }
        .buttonStyle(.bordered)
        .accessibilityIdentifier(identifier == "timeline" ? "capture.askDay" : "\(identifier).askDay")
    }

    private var generate: some View {
        DayDigestGenerateButton(model: model, lifecycle: app.dayDigest, identifier: identifier)
    }

    @ViewBuilder private var actions: some View {
        if let digest = model.digest {
            Menu {
                Button { model.copyDigest(digest) } label: { Label("Copy Digest", systemImage: "doc.on.doc") }
                    .accessibilityIdentifier("capture.dayDigest.copyAll")
                Button { model.exportDigest(digest) } label: { Label("Export Markdown", systemImage: "square.and.arrow.up") }
            } label: { Label("Digest actions", systemImage: "ellipsis.circle") }
                .menuStyle(.borderlessButton)
                .fixedSize()
                .accessibilityLabel("Day digest actions")
                .accessibilityIdentifier("\(identifier).dayDigest.actions")
        }
    }
}

/// Reflects every digest run for the shown day, including a scheduled
/// catch-up, so a manual request cannot start a competing generation.
private struct DayDigestGenerateButton: View {
    @EnvironmentObject private var app: AppState
    @ObservedObject var model: CaptureModel
    @ObservedObject var lifecycle: DayDigestLifecycle
    let identifier: String

    var body: some View {
        let scheduledRun = lifecycle.isGenerating(on: model.day) && !model.generating
        let busy = model.generating || scheduledRun
        Button { Task { await model.generateDigest(app: app) } } label: {
            Label(busy ? "Writing Digest…" : model.digest == nil ? "Write Digest" : "Regenerate",
                  systemImage: busy ? "hourglass" : "arrow.clockwise")
        }
        .buttonStyle(.bordered)
        .disabled(busy)
        .help(scheduledRun ? "The scheduled digest for this day is being written" : "")
        .accessibilityIdentifier("\(identifier).dayDigest.generate")
        .onChange(of: scheduledRun) { wasRunning, isRunning in
            // Show the scheduled result as soon as it is saved.
            if wasRunning, !isRunning { model.refreshOverview(app: app) }
        }
    }
}

struct YesterdayDigestLine: View {
    @EnvironmentObject private var app: AppState
    let report: DreamReport
    let day: Date
    @State private var expanded = false

    private var label: String {
        TodayDreamSelection.isCurrent(report, referenceDate: day) ? "Yesterday"
            : DreamDay.date(fromKey: report.day)?.formatted(date: .abbreviated, time: .omitted) ?? "Previous workday"
    }

    private func linkedThread(_ id: String?) -> ActionThread? {
        guard let id else { return nil }
        return app.outcomeIndex.userActionThreads.first { $0.id == id }
    }

    var body: some View {
        DisclosureGroup(isExpanded: $expanded) {
            DreamBriefText(text: report.narrative)
            ForEach(Array(report.topActions.enumerated()), id: \.offset) { index, action in
                // A top action taken from the recorded candidates is the real
                // thread: it can be checked off here and stays in sync.
                if let thread = linkedThread(report.topActionThreadID(at: index)) {
                    ActionThreadRow(thread: thread)
                } else {
                    DreamBriefText(text: "• " + action)
                }
            }
            ForEach(Array((report.attention + report.repeatedWork + report.suggestedChecks + report.frictions).enumerated()), id: \.offset) { _, text in
                DreamBriefText(text: "• " + text)
            }
            if report.isFallback {
                Text("Previous-day summary uses captured evidence only.").workspaceTextRole(.supporting)
            }
            if report.inferenceProvenance?.location == .remote {
                Label("Previous-day summary used approved remote inference", systemImage: "network")
                    .workspaceTextRole(.trust)
            }
            Text(report.provenanceDescription).workspaceTextRole(.metadata)
            if TodayDreamSelection.isRetryableFailure(report, referenceDate: day) {
                Button(app.dreaming.isDreaming ? "Updating…" : "Retry previous-day summary") { app.dreamNow() }
                    .disabled(app.dreaming.isDreaming || !app.libraryReady)
                    .accessibilityIdentifier("today.dream.retry")
            }
        } label: {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(label).font(AppFont.scaled(.body).weight(.semibold))
                Text(report.narrative).lineLimit(1).foregroundStyle(.secondary)
            }
        }
        .help(report.provenanceDescription)
        .accessibilityIdentifier("today.dream")
    }
}
