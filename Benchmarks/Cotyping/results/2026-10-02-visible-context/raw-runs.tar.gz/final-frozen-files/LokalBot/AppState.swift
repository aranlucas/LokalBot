import SwiftUI
import Combine
import AVFoundation
import CoreGraphics

/// Central app state (the "coordinator" from the design doc §6): dependency
/// wiring, the meeting library, navigation, and the detection→recording glue.
/// The recording lifecycle itself lives in `RecordingController`; headless
/// subcommands in `HeadlessCommandRunner`; AppKit launch plumbing in
/// `AppLifecycle.swift`.
@MainActor
final class AppState: ObservableObject {

    enum NavSection: Hashable {
        case today, timeline, meetings, people, projects, ask, agent, settings

        /// Section names accepted from the UI-test capture environment and
        /// deep links. Legacy names keep working: "capture" (the pre-split
        /// merged section) lands on Timeline, "dictation" and "cotyping" on
        /// Writing settings, "search"/"chat" on Ask (spec §2.1), and "models" on
        /// Settings, which absorbed it as a tab (spec §2.5).
        init?(captureName: String) {
            switch captureName.lowercased() {
            case "today": self = .today
            case "timeline", "capture": self = .timeline
            case "meetings": self = .meetings
            case "people": self = .people
            case "projects": self = .projects
            case "write", "type", "dictation", "cotyping", "autocomplete": self = .settings
            case "ask", "search", "chat": self = .ask
            case "agent": self = .agent
            case "settings", "models": self = .settings
            default: return nil
            }
        }
    }

    /// Which tool the Type section shows. Session-sticky: preserved while
    /// navigating away so returning lands on the last-used tab.
    enum TypeTab: String {
        case dictation, cotyping

        /// Legacy capture names select their tab; anything else leaves the
        /// current tab untouched.
        init?(captureName: String) {
            switch captureName.lowercased() {
            case "dictation": self = .dictation
            case "cotyping", "autocomplete": self = .cotyping
            default: return nil
            }
        }
    }

    /// Which tab the Settings surface shows (spec §2.5 — Settings absorbs
    /// Models as a tab strip). Session-sticky like TypeTab.
    enum SettingsTab: String, CaseIterable {
        case general, recording, dayMemory, writing, models, privacy, advanced

        var displayName: String {
            switch self {
            case .recording: "Meetings"
            case .dayMemory: "Day Memory"
            case .privacy: "Privacy & Data"
            default: rawValue.capitalized
            }
        }

        var icon: String {
            switch self {
            case .general: "gearshape"
            case .recording: "person.2"
            case .dayMemory: "calendar.day.timeline.left"
            case .writing: "pencil"
            case .models: "shippingbox"
            case .privacy: "lock"
            case .advanced: "slider.horizontal.3"
            }
        }

        /// Legacy capture names select their tab; the pre-merge "models"
        /// section name lands on the Models tab.
        init?(captureName: String) {
            switch captureName.lowercased() {
            case "general": self = .general
            case "recording", "meetings": self = .recording
            case "daymemory", "day memory": self = .dayMemory
            case "writing", "write": self = .writing
            case "models": self = .models
            case "privacy": self = .privacy
            case "advanced": self = .advanced
            default: return nil
            }
        }
    }

    /// True when launched by an XCUITest harness — gates the side-effectful
    /// startup paths (Core Audio polling, accessibility-trusted detector,
    /// Sparkle, periodic screenshots) so the UI renders against synthetic
    /// data without touching real audio, TCC, or the network.
    nonisolated static var isUITesting: Bool { UITestRuntime.isEnabled }
    /// The UI Test Host's background mode runs the interactive start against
    /// a replayed capture trace and file audio (Debug test hooks only).
    nonisolated static var runsBackgroundWorkInUITests: Bool {
#if LOKALBOT_TEST_HOOKS
        TestHooks.backgroundHostEnabled
#else
        false
#endif
    }
    /// Hosted XCTest executes the real app entry point. It needs neither UI
    /// fixtures nor any interactive service, so return before touching the
    /// meeting library, indexes, permissions, audio, Sparkle, or the network.
    nonisolated static var isUnitTesting: Bool { UITestRuntime.isUnitTesting }

    /// UserDefaults flag: the permission onboarding has been shown once. Also
    /// read by `AppDelegate` to keep the first run windowed.
    nonisolated static let onboardingShownKey = "lokalbotv3.onboarding.shown"

    @Published private(set) var meetings: [Meeting] = []
    @Published var lastError: String?
    /// A recording or dictation start was refused because microphone access
    /// is denied at the system level. Cleared when the user opens System
    /// Settings from the recovery toast or dismisses it.
    @Published var micRecoveryNeeded = false

    /// The always-alive settings owner; services capture this, never AppState.
    let settingsStore = SettingsStore()

    /// UI-facing settings surface (views bind `$app.settings.x`). Writes flow
    /// through to `settingsStore` (which persists) and fan out to the
    /// subsystems that apply settings live.
    @Published var settings: AppSettings {
        didSet {
            guard settings != oldValue else { return }
            settingsStore.current = settings
            if settings.appTheme != oldValue.appTheme {
                AppAppearance.apply(theme: settings.appTheme)
            }
            if settings.textSize != oldValue.textSize {
                AppAppearance.apply(textSize: settings.textSize)
            }
            modelRoles.settingsDidChange(from: oldValue, to: settings)
            if settings.stopDebounceSeconds != oldValue.stopDebounceSeconds {
                detector.stopDebounce = settings.stopDebounceSeconds
            }
            if settings.calendarDetectionEnabled != oldValue.calendarDetectionEnabled {
                detector.calendarEnabled = settings.calendarDetectionEnabled
            }
            if settings.requireCalendarForBrowser != oldValue.requireCalendarForBrowser {
                detector.requireCalendarForBrowser = settings.requireCalendarForBrowser
            }
            if interactive {
                if Self.dictationLifecycleChanged(from: oldValue, to: settings) {
                    dictation.applySettings()
                }
                if Self.cotypingLifecycleChanged(from: oldValue, to: settings) {
                    cotyping.applySettings()
                    if oldValue.cotypingEnabled && !settings.cotypingEnabled {
                        scheduleCotypingRuntimeUnload()
                    }
                }
                if Self.cotypingRuntimeChanged(from: oldValue, to: settings) {
                    scheduleCotypingPrewarm()
                }
                if settings.quickRecallEnabled != oldValue.quickRecallEnabled {
                    applyQuickRecallSetting()
                }
                // UI retention reductions are reviewed and executed explicitly.
                // Changing a preference must not trigger an unreviewed cleanup.
                if Self.dailyMemoryExportChanged(from: oldValue, to: settings) {
                    applyDailyMemoryExportSetting()
                }
                if Self.dayDigestChanged(from: oldValue, to: settings) {
                    applyDayDigestSetting()
                }
                if Self.codingAgentEvidenceChanged(from: oldValue, to: settings) {
                    applyCodingAgentEvidenceSetting()
                }
                if Self.screenContextChanged(from: oldValue, to: settings) {
                    applyTrackingSetting()
                }
                if Self.memoryRoutinesChanged(from: oldValue, to: settings) {
                    applyMemoryRoutineSetting()
                }
                if Self.dreamingChanged(from: oldValue, to: settings) {
                    applyDreamingSetting()
                }
            }
        }
    }

    private static func dictationLifecycleChanged(from old: AppSettings, to new: AppSettings) -> Bool {
        old.dictationEnabled != new.dictationEnabled
            || old.dictationShowOverlay != new.dictationShowOverlay
            || old.dictationLivePreview != new.dictationLivePreview
    }

    static func cotypingLifecycleChanged(from old: AppSettings, to new: AppSettings) -> Bool {
        old.cotypingEnabled != new.cotypingEnabled
            || old.cotypingExcludedApps != new.cotypingExcludedApps
            || old.cotypingExcludedDomains != new.cotypingExcludedDomains
            || old.cotypingUseVisibleContext != new.cotypingUseVisibleContext
            || old.excludedApps != new.excludedApps
            || old.excludedScreenDomains != new.excludedScreenDomains
            || old.cotypingUseMeetingMemory != new.cotypingUseMeetingMemory
            || old.cotypingUseScreenMemory != new.cotypingUseScreenMemory
            || old.dreamingEnabled != new.dreamingEnabled
    }

    private static func cotypingRuntimeChanged(from old: AppSettings, to new: AppSettings) -> Bool {
        guard new.cotypingEnabled else { return false }
        return !old.cotypingEnabled
            || old.cotypingBuiltInModelID != new.cotypingBuiltInModelID
            || old.cotypingInProcessRuntime != new.cotypingInProcessRuntime
            || old.customBuiltInModels != new.customBuiltInModels
    }

    private static func dailyMemoryExportChanged(from old: AppSettings,
                                                 to new: AppSettings) -> Bool {
        old.dailyMemoryExportEnabled != new.dailyMemoryExportEnabled
            || old.dailyMemoryExportFolder != new.dailyMemoryExportFolder
            || old.dailyMemoryExportFormat != new.dailyMemoryExportFormat
            || old.dailyMemoryExportHour != new.dailyMemoryExportHour
    }

    /// The custom prompt is deliberately absent: it is read fresh from
    /// `settings` at generation time, so editing it never resets the scheduler.
    private static func dayDigestChanged(from old: AppSettings,
                                         to new: AppSettings) -> Bool {
        old.dayDigestAutoEnabled != new.dayDigestAutoEnabled
            || old.dayDigestHour != new.dayDigestHour
            || automaticInferenceChanged(from: old, to: new)
    }

    /// Retention bounds which days are read, so it restarts ingestion too.
    private static func codingAgentEvidenceChanged(from old: AppSettings,
                                                   to new: AppSettings) -> Bool {
        CodingAgentEvidenceIngestor.Configuration(settings: old)
            != CodingAgentEvidenceIngestor.Configuration(settings: new)
    }

    private static func screenContextChanged(from old: AppSettings,
                                             to new: AppSettings) -> Bool {
        old.trackingEnabled != new.trackingEnabled
            || old.effectiveScreenContextCaptureMode != new.effectiveScreenContextCaptureMode
            || old.screenshotIntervalMinutes != new.screenshotIntervalMinutes
            || old.meetingVisualContextEnabled != new.meetingVisualContextEnabled
            || old.excludedApps != new.excludedApps
            || old.excludedScreenDomains != new.excludedScreenDomains
    }

    private static func memoryRoutinesChanged(from old: AppSettings,
                                              to new: AppSettings) -> Bool {
        old.memoryRoutinesEnabled != new.memoryRoutinesEnabled
            || old.memoryRoutineFolder != new.memoryRoutineFolder
            || old.enabledMemoryRoutines != new.enabledMemoryRoutines
            || old.memoryRoutineHour != new.memoryRoutineHour
            || old.memoryRoutineWeekday != new.memoryRoutineWeekday
    }

    private static func dreamingChanged(from old: AppSettings,
                                        to new: AppSettings) -> Bool {
        old.dreamingEnabled != new.dreamingEnabled
            || old.dreamingHour != new.dreamingHour
            || old.dreamingFirstEligibleDayKey != new.dreamingFirstEligibleDayKey
            || automaticInferenceChanged(from: old, to: new)
    }

    private static func automaticInferenceChanged(from old: AppSettings, to new: AppSettings) -> Bool {
        old.summarizerBackend != new.summarizerBackend
            || old.openAIBaseURL != new.openAIBaseURL || old.ollamaBaseURL != new.ollamaBaseURL
            || old.approvedRemoteInferenceOrigins != new.approvedRemoteInferenceOrigins
    }

    // Navigation (main window): sidebar section and selected meeting.
    @Published var navSection: NavSection = .today
    @Published var showingActions = false
    @Published var meetingNoteDrafts: [UUID: String] = [:]
    @Published var actionSelection: Set<String> = []
    @Published var recallQuery = ""
    @Published var recallState = RecallWorkspaceState()
    @Published var evidenceMeetingID: UUID?
    @Published var evidenceReturnSection: NavSection?
    private var evidenceReturnMeetingIDs: Set<Meeting.ID>?
    func returnFromEvidence() {
        guard let section = evidenceReturnSection else { return }
        if let evidenceReturnMeetingIDs { selectedMeetingIDs = evidenceReturnMeetingIDs }
        navSection = section
        evidenceReturnSection = nil
        evidenceReturnMeetingIDs = nil
    }
    @Published var meetingWorkspaceTabs: [UUID: MeetingWorkspaceTab] = [:]
    var meetingPlaybackPositions: [UUID: TimeInterval] = [:]
    var meetingPlaybackSpeeds: [UUID: Float] = [:]
    func openActions() { showingActions = true; navSection = .today }

    /// People and Projects share one derived read model.
    @Published var selectedPersonID: String?
    @Published var selectedProjectID: String?
    private(set) lazy var connections = WorkMemoryConnections()

    /// The meeting whose follow-up draft sheet is open, from any entry point.
    @Published var followUpDraftMeeting: Meeting?

    func draftFollowUp(for meeting: Meeting) {
        followUpDraftMeeting = meeting
    }

    /// The most recent finished meeting that has extracted outcomes.
    var latestMeetingWithOutcomes: Meeting? {
        outcomeIndex.all.first { !$0.isArchived && $0.meeting.endedAt != nil }?.meeting
    }

    func openPerson(_ id: String) {
        selectedPersonID = id
        navSection = .people
    }

    func openProject(_ id: String) {
        selectedProjectID = id
        navSection = .projects
    }

    @Published private(set) var actionCompletionHints: [String: ActionCompletionHint] = [:]
    private var completionHintTask: Task<Void, Never>?
    private static let dismissedCompletionHintsKey = "actions.dismissedCompletionHints"
    private static let maximumDismissedCompletionHints = 500

    /// "Looks done?" suggestions for open actions from later retained screen
    /// text. Suggestions only; status changes stay the user's.
    func refreshActionCompletionHints() {
        guard settings.suggestActionCompletion,
              settings.effectiveScreenContextCaptureMode.capturesText else {
            completionHintTask?.cancel()
            if !actionCompletionHints.isEmpty { actionCompletionHints = [:] }
            return
        }
        let threads = outcomeIndex.openUserActionThreads
        let databaseURL = activityStore.databaseURL
        let dismissed = Set(UserDefaults.standard.stringArray(forKey: Self.dismissedCompletionHintsKey) ?? [])
        completionHintTask?.cancel()
        completionHintTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(400))
            guard !Task.isCancelled else { return }
            let hints = await Task.detached(priority: .utility) {
                ActionCompletionDetector.hints(
                    for: threads, store: ActivityStore(databaseURL: databaseURL, readOnly: true),
                    dismissed: dismissed)
            }.value
            guard !Task.isCancelled, let self else { return }
            if self.actionCompletionHints != hints { self.actionCompletionHints = hints }
        }
    }

    func dismissActionCompletionHint(_ hint: ActionCompletionHint) {
        var dismissed = UserDefaults.standard.stringArray(forKey: Self.dismissedCompletionHintsKey) ?? []
        dismissed.append(hint.dismissalKey)
        UserDefaults.standard.set(Array(dismissed.suffix(Self.maximumDismissedCompletionHints)),
                                  forKey: Self.dismissedCompletionHintsKey)
        actionCompletionHints[hint.threadID] = nil
    }

    func refreshConnections() {
        connections.refresh(.init(
            meetings: meetings.filter { !$0.isMergedSource },
            projections: outcomeIndex.all,
            memory: dreamMemory,
            root: storage.rootURL,
            activityDatabaseURL: activityStore.databaseURL))
    }
    private static let typeTabDefaultsKey = "lokalbotv3.type.selectedTab"
    private static var navigationDefaults: UserDefaults {
        if let suite = UITestRuntime.defaultsSuiteName,
           let defaults = UserDefaults(suiteName: suite) {
            return defaults
        }
        return .standard
    }
    @Published var typeTab: TypeTab = .dictation {
        didSet { Self.navigationDefaults.set(typeTab.rawValue, forKey: Self.typeTabDefaultsKey) }
    }
    private static let settingsTabDefaultsKey = "lokalbotv3.settings.selectedTab"
    @Published var settingsTab: SettingsTab = .general {
        didSet { Self.navigationDefaults.set(settingsTab.rawValue, forKey: Self.settingsTabDefaultsKey) }
    }
    @Published var focusedSettingID: String?
    /// Ask's retrieval choice survives NavigationSplitView remounts while the
    /// app is running. Explicit handoffs and conversation selections still
    /// switch back to Ask before presenting their content.
    @Published var askMode: AskMode = .ask
    @Published var selectedMeetingIDs: Set<Meeting.ID> = []
    /// The meeting whose page-level find bar is visible. Keeping presentation
    /// in shared observable state makes menu/AppKit requests and the rendered
    /// NavigationSplitView consume one source of truth.
    @Published private(set) var presentedMeetingSearchID: Meeting.ID?
    @Published private(set) var meetingPageSearchRequestRevision = 0

    /// One date boundary for Ask search, answer tools and restored questions.
    /// The single-day adapter keeps Timeline navigation handoffs compatible.
    @Published var askDateScope: AskDateScope?
    var askDayScope: Date? {
        get {
            guard let scope = askDateScope, scope.firstDay == scope.lastDay else { return nil }
            return AskDayScope.date(for: scope.firstDay)
        }
        set { askDateScope = newValue.map { AskDateScope(day: $0) } }
    }
    /// Atomic, destination-scoped payloads for cross-surface navigation.
    private(set) lazy var navigationHandoff = NavigationHandoff()

    /// Keep legacy writing commands routed to the corresponding Settings section.
    func openType(_ tab: TypeTab) {
        typeTab = tab
        openSettings(tab: .writing)
        focusedSettingID = tab == .cotyping ? "settings.autocompletePreview" : "settings.dictationPreview"
    }

    /// Open Settings as a destination inside the existing main window.
    func openSettings(tab: SettingsTab? = nil) {
        if let tab { settingsTab = tab }
        focusedSettingID = nil
        evidenceReturnSection = nil
        navSection = .settings
        WindowAccess.shared.open("main")
    }

    /// Navigate to the Ask section, optionally pre-filling the query and/or
    /// scoping it to a day (Timeline's "Ask about this day").
    func openAsk(query: String = "", dayScope: Date? = nil,
                 screenSnapshotIDs: [Int64]? = nil, submit: Bool = false,
                 meetingIDs: Set<Meeting.ID>? = nil, mode: AskMode = .ask) {
        navigationHandoff.stageAsk(
            query: query,
            dayScope: dayScope,
            screenSnapshotIDs: screenSnapshotIDs,
            submit: submit, meetingIDs: meetingIDs, mode: mode)
        navSection = .ask
    }

    func openAgent(_ context: AgentLaunchContext? = nil) {
        navigationHandoff.stageAgent(context)
        if let prompt = context?.prompt {
            agentSessions.ensureSelectedController().draft = prompt
        }
        navSection = .agent
    }

    /// Open one meeting in the Meetings section — the deep-link target
    /// for search hits, menu-bar recents, and palette recents.
    func openMeeting(_ id: Meeting.ID, seek: TimeInterval? = nil, intent: EvidenceIntent = .reveal) {
        evidenceMeetingID = id
        if navSection != .meetings {
            evidenceReturnSection = navSection
            evidenceReturnMeetingIDs = selectedMeetingIDs
        }
        navigationHandoff.stageMeeting(id, seek: seek, intent: intent)
        selectedMeetingIDs = [id]
        navSection = .meetings
    }

    var canSearchSelectedMeeting: Bool {
        navSection == .meetings && selectedMeeting?.endedAt != nil
    }

    func requestSelectedMeetingSearch() {
        guard canSearchSelectedMeeting, let meeting = selectedMeeting else { return }
        presentedMeetingSearchID = meeting.id
        meetingPageSearchRequestRevision &+= 1
    }

    func dismissMeetingSearch(for meetingID: Meeting.ID) {
        guard presentedMeetingSearchID == meetingID else { return }
        presentedMeetingSearchID = nil
    }

    func selectDefaultMeetingIfNeeded() {
        guard selectedMeetingIDs.isEmpty else { return }
        if let live = currentMeeting {
            openMeeting(live.id)
        } else if let completed = meetings.first(where: { meeting in
            meeting.endedAt != nil && pipeline.stages[meeting.id] == nil
        }) ?? meetings.first(where: { $0.endedAt != nil }) {
            openMeeting(completed.id)
        }
    }

    /// The meeting shown in the detail pane (single selection only). The
    /// in-progress recording is a first-class citizen here: selecting its
    /// row resolves to `currentMeeting`, which `CaptureDetailView` routes
    /// to the live view.
    var selectedMeeting: Meeting? {
        guard selectedMeetingIDs.count == 1, let id = selectedMeetingIDs.first else { return nil }
        if let live = currentMeeting, live.id == id { return live }
        return meetings.first { $0.id == id }
    }

    let storage = StorageManager()
    private(set) lazy var outcomeIndex = OutcomeIndex(
        storage: storage,
        mutateEvidence: { [weak self] meetings, mutation in
            guard let self else { throw CancellationError() }
            try self.withPrimaryEvidenceChange(for: meetings, mutation)
        },
        onEvidenceChanged: { [weak self] meetings in
            self?.primaryEvidenceDidChange(for: meetings)
            // Outcome corrections and status are searchable.
            for meeting in meetings { self?.reindexSearchInBackground(meeting) }
        })
    private(set) lazy var cotypingLearning = CotypingLearningStore(storageRoot: storage.rootURL)
    let detector = MeetingDetector()
    let audioMonitor = AudioSourceMonitor()
    /// External-agent access: Privacy marker plus the local-model wake watcher.
    private(set) lazy var agentAccess = AgentAccessManager(
        storage: storage,
        settings: { [weak self] in self?.settings ?? AppSettings.load() },
        onError: { [weak self] message in self?.lastError = message })
    /// Screen-memory access is intentionally separate from meeting-library
    /// access: enabling one capability never grants the other.
    private(set) lazy var screenMemoryAccess = ScreenMemoryAccessManager(
        gate: ScreenMemoryAccessGate(root: storage.rootURL))
    private(set) lazy var quickRecallHotKey: QuickRecallHotKeyController = {
        let controller = QuickRecallHotKeyController()
        controller.onInvoke = { WindowAccess.shared.open("quick-recall") }
        return controller
    }()
    private let dailyMemoryExportScheduler = DailyMemoryExportScheduler()
    private(set) lazy var memoryRoutines = MemoryRoutineScheduler(
        storageRoot: storage.rootURL,
        databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"),
        canRun: { [weak self] in
            guard let self else { return false }
            let cotypingGenerating: Bool
            if case .generating = self.cotyping.state {
                cotypingGenerating = true
            } else {
                cotypingGenerating = false
            }
            return !self.recording.isRecording
                && !self.recording.isStarting
                && !self.dictation.isStarting
                && !self.dictation.state.isWorking
                && !cotypingGenerating
                && !self.pipeline.hasActiveWork
        })
    /// Overnight dreaming: the scheduler is observed by Settings (progress /
    /// last-run), the store is read by Today, and `latestDreamReport` lets an
    /// open Today window pick up a dream that finishes while it's visible.
    @Published var latestDreamReport: DreamReport?
    /// Settings' user-managed pin controls. The store remains the source of
    /// truth; mutations reload it before saving to avoid stale-view writes.
    @Published private(set) var dreamMemory: DreamMemory?
    private var dreamObserver: AnyCancellable?
    private(set) lazy var dreamStore = DreamStore(root: storage.rootURL)
    private(set) lazy var dreaming: DreamScheduler = {
        let scheduler = DreamScheduler()
        dreamObserver = scheduler.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        return scheduler
    }()
    /// Read-only calendar access (EventKit): confirms meetings and titles
    /// recordings. Concrete type so the settings UI observes its permission
    /// state; handed to the detector as the `CalendarEventProviding` seam.
    let calendar = EventKitCalendarEventProvider()
    private var cachedSearchIndex: SearchIndex?
    var searchIndex: SearchIndex {
        if let cachedSearchIndex { return cachedSearchIndex }
        let created = SearchIndex(
            databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"))
        for meetingID in excludedMeetingIDs { created.noteDeletion(meetingID) }
        cachedSearchIndex = created
        return created
    }
    private(set) lazy var activityStore = ActivityStore(
        databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"))
    private(set) lazy var sampler = ActivitySampler(store: activityStore)
    private var cachedEmbeddingIndex: EmbeddingIndex?
    var embeddingIndex: EmbeddingIndex {
        if let cachedEmbeddingIndex { return cachedEmbeddingIndex }
        let created = EmbeddingIndex(
            databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"),
            storage: storage)
        for meetingID in excludedMeetingIDs { created.noteDeletion(meetingID) }
        cachedEmbeddingIndex = created
        return created
    }
    private(set) lazy var screenshots = ScreenshotService(
        store: activityStore, storage: storage, sampler: sampler,
        isMeetingRecordingActive: { [weak self] in
            guard let self else { return false }
            return self.recording.isRecording || self.recording.isStarting
        }, activeMeetingID: { [weak self] in
            self?.recording.currentMeeting?.id
        }, isHighPriorityInteractionActive: { [weak self] in
            guard let self else { return false }
            if self.dictation.state.isWorking { return true }
            if case .generating = self.cotyping.state { return true }
            return false
        }) { [store = settingsStore] in
        store.current
    }
    private(set) lazy var pipelineJobStore = PipelineJobStore(
        databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"))
    /// Backend selection, preparation, privacy policy, leases, and recovery
    /// for every feature that uses LokalBot's Think role.
    private(set) lazy var thinkExecution = ThinkExecution(storage: storage)
    private(set) lazy var speakerIdentity = MeetingSpeakerIdentityService(
        storage: storage, settings: { [store = settingsStore] in store.current })
    private(set) lazy var pipeline = ProcessingPipeline(
        storage: storage,
        jobStore: pipelineJobStore,
        settings: { [store = settingsStore] in store.current },
        thinkExecution: thinkExecution,
        speakerIdentity: speakerIdentity,
        automationReadiness: ProcessingPipeline.defaultAutomationReadiness)
    /// Canonical state machine for Transcribe, Think, and Autocomplete.
    private(set) lazy var modelRoles = ModelRoles(
        settings: { [store = settingsStore] in store.current },
        storage: storage,
        onReadinessChanged: { [weak self] in
            self?.processMeetingsWaitingForModels()
        })

    private(set) lazy var modelSetup = ModelSetupController(
        settings: { [weak self] in self?.settings ?? AppSettings() },
        update: { [weak self] in self?.settings = $0 },
        prepare: { [weak self] patch, current in
            guard let self else { throw CancellationError() }
            let target = patch.applying(to: current)
            for id in patch.localModelIDs(in: current) {
                guard let entry = ModelCatalog.entry(id: id, custom: target.customBuiltInModels) else {
                    throw ModelDownloadManager.PreparationError.failed("This model is no longer in the catalog. Choose another model.")
                }
                _ = try await ModelDownloadManager.shared.ensureAvailable(entry, storage: self.storage)
            }
            if let transcription = patch.transcription {
                try await self.modelRoles.ensureTranscriptionAvailable(transcription, configuration: target)
            }
            if patch.backend == .appleIntelligence {
                let availability = FoundationModelAvailability.current()
                guard availability.isAvailable else {
                    throw ModelDownloadManager.PreparationError.failed(availability.reason ?? "Apple Intelligence is unavailable.")
                }
            }
            for id in patch.localModelIDs(in: current) {
                guard let entry = ModelCatalog.entry(id: id, custom: target.customBuiltInModels),
                      ModelCatalog.localURL(for: entry, storage: self.storage) != nil else {
                    throw ModelDownloadManager.PreparationError.failed(
                        "A prepared model is no longer on disk. Download it again before switching.")
                }
            }
            self.modelRoles.readinessDidChange()
        })

    let modelChecks = ModelCheckController()
    private(set) lazy var speechModelDownload = ModelSpeechDownloadController()
    /// One Day Digest lifecycle for manual, scheduled, and headless callers.
    /// It owns evidence collection, journal state, freshness, and repair policy.
    private(set) lazy var dayDigest = DayDigestLifecycle(
        storage: storage,
        activityStore: activityStore,
        pipeline: pipeline,
        meetings: { [weak self] in
            guard let self else { return [] }
            return (self.currentMeeting.map { [$0] } ?? []) + self.meetings
        },
        settings: { [store = settingsStore] in store.current },
        prepareEvidence: { [weak self] day in await self?.codingAgentEvidence.refresh(including: day) },
        onGenerated: { [weak self] day in self?.dayDigestDidChange(on: day) })
    /// Settled Claude Code and Codex work, read into the activity store while
    /// the person has opted in.
    private(set) lazy var codingAgentEvidence = CodingAgentEvidenceIngestor(
        store: activityStore,
        configuration: { [store = settingsStore] in .init(settings: store.current) },
        mutateEvidence: { [weak self] days, mutation in
            try self?.withPrimaryEvidenceChange(on: days, mutation)
        },
        onChange: { [weak self] days in self?.codingAgentEvidenceDidChange(on: days) })
    /// Meeting-recording lifecycle: recorders, watchdog, timer tick, prewarm.
    private(set) lazy var recording = RecordingController(
        storage: storage,
        settingsStore: settingsStore,
        audioMonitor: audioMonitor,
        pipeline: pipeline,
        isInteractive: { [weak self] in self?.interactive ?? false },
        onError: { [weak self] message in
            guard let message else {
                // Withdraw only the silent-capture advisory, never a newer error.
                if self?.lastError == RecordingController.silentSystemAudioMessage {
                    self?.lastError = nil
                }
                return
            }
            self?.lastError = message
        },
        onMicPermissionDenied: { [weak self] in self?.micRecoveryNeeded = true },
        onMeetingFinished: { [weak self] meeting in self?.meetings.insert(meeting, at: 0) })
    /// Press-and-speak composition. Every dictation is treated as a writing
    /// request: local ASR captures the instruction, the configured composition
    /// LLM writes against ephemeral focused-window context, and focus-safe
    /// delivery inserts it.
    private(set) lazy var dictation = DictationCoordinator(
        storageRoot: storage.rootURL,
        settingsProvider: { [weak self, store = settingsStore] in
            self?.dictationTranscriptionSettings(store.current) ?? store.current
        },
        makeTextEngine: { [weak self] sessionSettings in
            guard let self else {
                throw TextEngineError.unavailable("LokalBot is shutting down.")
            }
            let config = sessionSettings.dictationCompositionTextEngineSettings
            return try await self.thinkExecution.makeTextEngine(
                config,
                priority: .interactive,
                purpose: "dictation compose")
        },
        canStart: { [weak self] in
            guard let self else { return false }
            return !self.recording.isRecording
                && !self.recording.isStarting
                && self.pendingRecordingStart == nil
        },
        onBusy: { [weak self] in
            self?.lastError = "Stop the current meeting recording before starting dictation."
        },
        onError: { [weak self] message in
            self?.lastError = message
        },
        onMicPermissionDenied: { [weak self] in
            self?.micRecoveryNeeded = true
        })
    /// Cotyping (inline AI autocomplete). Always runs its own model on the
    /// dedicated `LlamaServer.cotyping` instance so it never thrashes the
    /// shared summarizer server. Resolved per-completion, so changes apply live.
    private(set) lazy var cotypingEngine = CotypingEngineSelector(
        http: CotypingEngine(
            makeEngine: { [weak self] in
                guard let self else { throw TextEngineError.unavailable("LokalBot is shutting down.") }
                return try await self.thinkExecution.makeTextEngine(
                    self.settings.cotypingTextEngineSettings,
                    server: .cotyping,
                    priority: .interactive,
                    purpose: "cotyping")
            },
            stopRuntime: { await LlamaServer.cotyping.stop() }),
        makeLocal: { modelPath in
            LocalLlamaCotypingEngine(runtime: LlamaCotypingRuntime(), modelPath: modelPath)
        },
        settings: { [store = settingsStore] in store.current },
        storage: storage)
    private(set) lazy var cotyping = CotypingCoordinator(
        engine: cotypingEngine,
        settingsProvider: { [store = settingsStore] in store.current },
        learningStore: cotypingLearning,
        memoryContextProvider: { [weak self] field, settings in
            guard let self, self.libraryReady,
                  CotypingMemoryContext.Policy(settings: settings).enabled else { return .empty }
            let root = self.storage.rootURL
            let meetings = self.meetings
            let task = Task.detached(priority: .userInitiated) {
                CotypingMemoryContextProvider.load(root: root, meetings: meetings, field: field, settings: settings)
            }
            return await withTaskCancellationHandler { await task.value } onCancel: { task.cancel() }
        },
        isMeetingRecordingActive: { [weak self] in
            guard let self else { return false }
            return self.recording.isRecording || self.recording.isStarting
        })
    /// Rolling live transcript of the recording in progress (preview only —
    /// the pipeline's post-meeting transcript stays authoritative).
    private(set) lazy var liveTranscriber = LiveMeetingTranscriber(
        storageRoot: storage.rootURL,
        settings: { [store = settingsStore] in store.current })

    @MainActor
    func prepareRecommendedCotypingModel() {
        CotypingModelPreparer.prepareRecommended(
            settings: &settings,
            storage: storage,
            downloads: ModelDownloadManager.shared)
    }

    /// Chat assistant (the "Chat" section). Reuses the summariser's `TextEngine`
    /// and a tool-calling agent over the live meeting list + search indexes.
    private(set) lazy var chat = ChatViewModel(
        makeEngine: { [weak self] in
            guard let self else { throw TextEngineError.unavailable("LokalBot is shutting down.") }
            return try await self.thinkExecution.makeTextEngine(
                self.settings,
                priority: .interactive,
                purpose: "chat")
        },
        tools: MeetingChatTools(
            meetings: { [weak self] in self?.meetings ?? [] },
            storage: storage,
            searchIndex: searchIndex,
            embeddingIndex: embeddingIndex,
            activityStore: activityStore,
            settings: { [store = settingsStore] in store.current }),
        store: ChatStore(rootURL: storage.rootURL),
        workMemory: { [weak self] in
            guard let self else { return "" }
            return ChatPrompt.workMemoryContext(
                memory: (try? self.dreamStore.loadMemory()) ?? nil,
                dreamingEnabled: self.settings.dreamingEnabled)
        }, deferHistoryLoading: true)

    // Agent Mode (pi). Installer and tab manager are cheap; each tab lazily
    // spawns its own controller/process when AgentView mounts it.
    let agentInstaller = AgentRuntimeInstaller()
    private(set) lazy var agentSessions = AgentSessionTabs(
        settings: { [store = settingsStore] in store.current },
        storage: storage,
        thinkExecution: thinkExecution)
    var agentController: AgentSessionController {
        agentSessions.ensureSelectedController()
    }

    private var pipelineObserver: AnyCancellable?
    private var outcomeObserver: AnyCancellable?
    private var dictationObserver: AnyCancellable?
    private var recordingObserver: AnyCancellable?
    private var recordingStatusObserver: AnyCancellable?
    private var audioMonitorObserver: AnyCancellable?
    private var audioMonitorChangeForwarder: AnyCancellable?
    private var calendarObserver: AnyCancellable?
    private var modelRolesObserver: AnyCancellable?
    private var navigationHandoffObserver: AnyCancellable?
    /// True only on the real interactive launch path (not headless / UI test) —
    /// gates recording notifications and first-run onboarding.
    private var interactive = false
    private var terminationCleanupTask: Task<Bool, Never>?
    /// Serializes cotyping model lifecycle transitions. A disable must finish
    /// unloading both runtimes before a rapid re-enable can prewarm a fresh
    /// model, otherwise the old and new routes can overlap in memory.
    private var cotypingRuntimeTask: Task<Void, Never>?
    private var cotypingRuntimeTaskID: UUID?
    private var libraryLoadTask: Task<Void, Never>?
    private var embeddingBackfillTask: (token: UUID, task: Task<Void, Never>)?
    /// Meetings re-embedded so far by the library backfill, while it runs.
    @Published private(set) var embeddingBackfill: BackgroundCount?
    /// Long-running work for the sticky sidebar progress card.
    let backgroundActivity = BackgroundActivityMonitor()
    private var embeddingIndexTasks: [Meeting.ID: (token: UUID, task: Task<Void, Never>)] = [:]
    private var indexCleanupTasks: [Meeting.ID: (token: UUID, task: Task<Void, Never>)] = [:]
    /// Meeting IDs excluded from search for this session. This includes
    /// physically deleted meetings and source rows folded into a merge.
    private var excludedMeetingIDs: Set<Meeting.ID> = []
    @Published private(set) var libraryReady = false
    private var pendingRecordingStart: (
        context: MeetingDetectionContext?,
        source: String,
        systemAudioPolicy: RecordingSystemAudioPolicy
    )?
    private lazy var searchIndexWorkQueue = SearchIndexWorkQueue(
        databaseURL: storage.rootURL.appendingPathComponent("lokalbotv3.sqlite"),
        rootURL: storage.rootURL)

    // Recording facades — views observe AppState only.
    var isRecording: Bool { recording.isRecording }
    var currentMeeting: Meeting? { recording.currentMeeting }

    func startRecording(
        context: MeetingDetectionContext? = nil,
        source: String = "ui",
        systemAudioPolicy: RecordingSystemAudioPolicy = .meetingAppWhenAvailable
    ) {
        RecordingNotifier.shared.invalidateMeetingDetections()
        if let sessionID = context?.detectorSessionID,
           detector.activeSessionID != sessionID { return }
        guard !dictation.isStarting, !dictation.state.isWorking else {
            lastError = "Finish or cancel dictation before starting a meeting recording."
            return
        }
        guard libraryReady else {
            pendingRecordingStart = (context, source, systemAudioPolicy)
            lastError = "Preparing your meeting library; recording will start when it is ready."
            return
        }
        recording.start(
            context: context,
            source: source,
            systemAudioPolicy: systemAudioPolicy)
    }

    func stopRecording(process: Bool = true) {
        if !libraryReady {
            pendingRecordingStart = nil
            return
        }
        recording.stop(process: process)
    }

    /// Recording started, stopped, or split to a new meeting: quiet cotyping
    /// and (re)point the live transcriber at the active meeting folder.
    private func meetingRecordingStateDidChange(active: Bool) {
        guard interactive else { return }
        if settings.cotypingEnabled {
            cotyping.meetingRecordingStateChanged(active: active)
        }
        if active, let meeting = recording.currentMeeting {
            liveTranscriber.prepare(folder: meeting.folderURL(in: storage))
        } else {
            liveTranscriber.stop(preservingHandoff: recording.isSplittingForCalendarHandoff)
        }
    }

    /// Menu-bar path to the live meeting: land on the library with the
    /// in-progress recording selected, so the detail pane shows the live
    /// transcript and notes.
    func showLiveMeeting() {
        guard let live = currentMeeting else { return }
        navSection = .meetings
        selectedMeetingIDs = [live.id]
        WindowAccess.shared.open("main")
    }

    init() {
        AppLog.bootstrap()
        settings = settingsStore.current
        // AppKit-drawn text reads this before any window exists.
        AppAppearance.apply(textSize: settings.textSize)
        if let raw = Self.navigationDefaults.string(forKey: Self.settingsTabDefaultsKey),
           let stored = SettingsTab(rawValue: raw) {
            settingsTab = stored
        }
        if let raw = Self.navigationDefaults.string(forKey: Self.typeTabDefaultsKey),
           let stored = TypeTab(rawValue: raw) {
            typeTab = stored
        } else {
            // Existing installs retain Dictation; genuinely new installs lead
            // with the approved Autocomplete experience.
            typeTab = Self.navigationDefaults.bool(forKey: Self.onboardingShownKey)
                ? .dictation : .cotyping
        }
        if Self.isUnitTesting { return }
        // Settings corruption is a privacy event, not a cosmetic one: a field
        // like screenshot capture silently resetting to its default changes
        // what the app records. Say exactly what fell back.
        if !settings.corruptedSettingsKeys.isEmpty {
            let keys = settings.corruptedSettingsKeys.joined(separator: ", ")
            lokalbotLog("settings decode fell back to defaults for: \(keys)")
            lastError = settings.corruptedSettingsKeys == [AppSettings.wholeStoreCorruptionMarker]
                ? "Saved settings could not be read and were reset to defaults. Review Settings — especially Privacy and Recording."
                : "Some saved settings could not be read and were reset to defaults (\(keys)). Review them in Settings."
        }
        let headlessCommand = HeadlessCommand.requested
        let needsSynchronousLibrary = headlessCommand != nil || Self.isUITesting
        if needsSynchronousLibrary {
            meetings = storage.loadMeetings()
            libraryReady = true
            outcomeIndex.refresh(meetings: meetings)
        }
        LiveMeetingTranscriber.sweepOrphanedSnapshots(storageRoot: storage.rootURL)
        // Views observe AppState only; forward pipeline / recording /
        // audio-monitor / calendar change notifications so MainWindowView
        // refreshes when those sub-ObservableObjects publish.
        pipelineObserver = pipeline.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        outcomeObserver = outcomeIndex.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        dictationObserver = Publishers.MergeMany([
            dictation.$state.dropFirst().map { _ in () }.eraseToAnyPublisher(),
            dictation.$isStarting.dropFirst().map { _ in () }.eraseToAnyPublisher(),
            dictation.$isShortcutMonitoringActive.dropFirst().map { _ in () }.eraseToAnyPublisher(),
            dictation.$lastTranscript.dropFirst().map { _ in () }.eraseToAnyPublisher(),
            dictation.$lastComposedText.dropFirst().map { _ in () }.eraseToAnyPublisher(),
            dictation.$lastEngine.dropFirst().map { _ in () }.eraseToAnyPublisher(),
        ]).sink { [weak self] in
            self?.objectWillChange.send()
        }
        // Forward lifecycle changes, but not RecordingController's one-second
        // `now` tick. Timer labels observe the controller directly; rebroadcasting
        // that tick through AppState invalidated the entire window hierarchy.
        recordingObserver = Publishers.CombineLatest(
            recording.$status,
            recording.$currentMeeting
        ).dropFirst().sink { [weak self] _ in
            self?.objectWillChange.send()
        }
        // React to recording start/stop (and calendar-handoff splits, which
        // change the meeting ID mid-recording): pause cotyping and run the
        // live transcriber against the active meeting folder.
        recordingStatusObserver = recording.$status
            .removeDuplicates()
            .dropFirst()
            .sink { [weak self] status in
                self?.pipeline.setCaptureActive(status != .idle)
                switch status {
                case .recording: self?.meetingRecordingStateDidChange(active: true)
                case .idle: self?.meetingRecordingStateDidChange(active: false)
                case .starting: break
                }
            }
        audioMonitorChangeForwarder = audioMonitor.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        calendarObserver = calendar.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        modelRolesObserver = modelRoles.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        navigationHandoffObserver = navigationHandoff.objectWillChange.sink { [weak self] in
            self?.objectWillChange.send()
        }
        pipeline.onArtifactsWillChange = { [weak self] meeting in
            guard let self else { return }
            try self.dayDigest.retractGeneratedJournals(for: [meeting.startedAt])
            self.dayDigest.reconsiderEvidence(for: meeting.startedAt)
        }
        pipeline.onArtifactsWritten = { [weak self] meeting in
            guard let self else { return }
            self.outcomeIndex.refresh(meeting: meeting)
            self.reindexSearchInBackground(meeting)
            if self.settings.semanticSearchEnabled {
                self.reindexEmbeddingInBackground(meeting)
            }
            self.primaryEvidenceDidChange(for: meeting)
        }
        if needsSynchronousLibrary {
            searchIndex.reindexAll(meetings, storage: storage)
        }
        if let command = headlessCommand {
            HeadlessCommandRunner(app: self).run(command)
            return
        }
        // UI tests render against pre-seeded fixtures, not a real audio/Sparkle
        // session — bail out before any subsystem reaches for the mic, the
        // process list, or the network.
        if Self.isUITesting && !Self.runsBackgroundWorkInUITests { return }
        interactive = true
        RecordingNotifier.shared.bootstrap()
        applyTrackingSetting()
        // Crash recovery: re-enqueue any meeting whose processing never
        // finished — a quit or crash mid-transcription used to lose the job.
        detector.onMeetingStarted = { [weak self] context in
            guard let self else { return }
            self.recording.considerDetectedSource(context)
            // A recording already capturing this call follows its end from now on.
            if self.settings.autoRecordMode != .manual, self.recording.joinDetectorSession(context) {
                RecordingNotifier.shared.invalidateMeetingDetections()
                return
            }
            switch self.settings.autoRecordMode {
            case .automatic: self.startRecording(context: context, source: "detector")
            case .ask: self.notifyMeetingDetected(context)
            case .manual: RecordingNotifier.shared.invalidateMeetingDetections()
            }
        }
        detector.onMeetingSwitched = { [weak self] context in
            guard let self else { return }
            switch self.settings.autoRecordMode {
            case .automatic:
                RecordingNotifier.shared.invalidateMeetingDetections()
                guard let sessionID = context.detectorSessionID,
                      self.recording.detectorSessionID == sessionID else { return }
                self.recording.splitForCalendarHandoff(context)
            case .ask:
                if self.recording.isRecording || self.recording.isStarting {
                    RecordingNotifier.shared.invalidateMeetingDetections()
                } else {
                    self.notifyMeetingDetected(context)
                }
            case .manual:
                RecordingNotifier.shared.invalidateMeetingDetections()
            }
        }
        detector.onMeetingEnded = { [weak self] event in
            RecordingNotifier.shared.invalidateMeetingDetections()
            guard let self else { return }
            if self.pendingRecordingStart?.context?.detectorSessionID == event.sessionID {
                self.pendingRecordingStart = nil
            }
            switch event.action(detectorSessionID: self.recording.detectorSessionID,
                                startedByUser: self.recording.startedByUser) {
            case .ignore: break
            case .stop(let allowsAutomaticRestart):
                self.recording.stop(contentEndedAt: event.contentEndedAt,
                                    allowsAutomaticRestart: allowsAutomaticRestart)
            }
        }
        detector.onBrowserObservation = { [weak self] sessionID, unavailable, lastVerifiedAt in
            self?.recording.updateCallObservation(sessionID: sessionID,
                                                  unavailable: unavailable,
                                                  lastVerifiedAt: lastVerifiedAt)
        }
        detector.onVerifiedSourceAvailable = { [weak self] context in
            guard let self else { return }
            self.recording.considerDetectedSource(context)
            if self.settings.autoRecordMode != .manual { self.recording.joinDetectorSession(context) }
        }
        detector.stopDebounce = settings.stopDebounceSeconds
        detector.calendar = calendar
        detector.calendarEnabled = settings.calendarDetectionEnabled
        detector.requireCalendarForBrowser = settings.requireCalendarForBrowser
        // The mic-in-use signal misses meetings with a muted mic. The audio
        // monitor is the complementary "a meeting app just started producing
        // audio output" signal. In automatic mode it records recognised
        // meeting sources; other candidates expire silently.
        audioMonitor.start()
        audioMonitorObserver = audioMonitor.$detectedProcess
            .compactMap { $0 }
            .sink { [weak self] process in self?.audioMonitorDetected(process) }
        detector.start()
        // Start Sparkle (silent background check). No-op on dev builds and
        // until the appcast feed URL + public key are configured (RELEASING.md).
        AppUpdateManager.shared.start()
        // Resume the wake watcher when the Privacy marker was left enabled.
        agentAccess.start()
        screenMemoryAccess.start()
        applyQuickRecallSetting()
        applyDailyMemoryExportSetting()
        applyDayDigestSetting()
        applyCodingAgentEvidenceSetting()
        applyMemoryRoutineSetting()
        applyDreamingSetting()
        applyHealthCheckSetting()
        bindBackgroundActivity()
        // First-run check. A genuinely-new user with missing permissions gets
        // onboarding (windowed — see AppDelegate); the flag persists only when
        // they explicitly finish or defer the wizard (OnboardingView footer),
        // so quitting mid-wizard re-opens it next launch. Fully-permissioned
        // installs that predate the flag are recognised as established right
        // away and start menu-bar-only next launch.
        if !UserDefaults.standard.bool(forKey: Self.onboardingShownKey) {
            if PermissionManager.shared.allGranted {
                UserDefaults.standard.set(true, forKey: Self.onboardingShownKey)
            } else {
                WindowAccess.shared.open("onboarding")
            }
        }
        // Bring optional system-wide automation up if the user left it enabled
        // and the grants are in place; otherwise it parks itself.
        dictation.applySettings()
        cotyping.applySettings()
        if settings.cotypingEnabled { scheduleCotypingPrewarm() }
        loadLibraryInBackground()
    }

    /// Large meeting libraries can take seconds to enumerate, repair, duration-
    /// probe, and FTS-index. Do that work on a utility executor and publish one
    /// sorted snapshot when ready instead of blocking the first app window.
    private func loadLibraryInBackground() {
        libraryLoadTask?.cancel()
        let rootURL = storage.rootURL
        libraryLoadTask = Task { @MainActor [weak self] in
            let worker = Task.detached(priority: .utility) {
                guard !Task.isCancelled else { return ([Meeting](), Set<UUID>()) }
                let workerStorage = StorageManager(rootURL: rootURL)
                let loaded = workerStorage.loadMeetings()
                // Earlier boundary reviews tombstoned live meetings, hiding
                // them from search; clear those before the reindex below.
                let restored = SearchIndex.clearStaleTombstones(
                    liveMeetingIDs: Set(loaded.map(\.id)),
                    databaseURL: rootURL.appendingPathComponent("lokalbotv3.sqlite"))
                return (loaded, restored)
            }
            let (loaded, restored) = await withTaskCancellationHandler {
                await worker.value
            } onCancel: {
                worker.cancel()
            }
            guard let self, !Task.isCancelled else { return }
            for meetingID in restored {
                lokalbotLog("search tombstone cleared for live meeting=\(meetingID)")
                self.cachedSearchIndex?.noteRestoration(meetingID)
                self.cachedEmbeddingIndex?.noteRestoration(meetingID)
            }

            var byID = Dictionary(uniqueKeysWithValues: loaded.map { ($0.id, $0) })
            // Preserve meetings created while the background scan was running.
            for meeting in self.meetings { byID[meeting.id] = meeting }
            let merged = byID.values.sorted { $0.startedAt > $1.startedAt }
            self.meetings = merged
            self.libraryReady = true
            self.speakerIdentity.maintainRetention(meetings: { [weak self] in self?.meetings ?? [] })
            Task { await self.outcomeIndex.refreshInBackground(meetings: merged) }
            self.pipeline.resumePending(meetings: merged)
            if self.settings.autoTranscribe {
                self.pipeline.enqueueMissingTranscriptions(
                    in: merged, summarize: self.settings.autoSummarize)
            }
            // Dreaming was deliberately gated while launch recovery rebuilt
            // the library and durable processing queue. Re-check immediately;
            // pending pipeline work will keep the downtime gate closed until a
            // later timer tick.
            self.dreaming.tick()
            self.reindexLibraryInBackground(merged)
            if self.settings.semanticSearchEnabled {
                self.reindexEmbeddingLibraryInBackground(merged)
            }
            self.libraryLoadTask = nil
            if let pending = self.pendingRecordingStart {
                self.pendingRecordingStart = nil
                self.lastError = nil
                self.startRecording(
                    context: pending.context,
                    source: pending.source,
                    systemAudioPolicy: pending.systemAudioPolicy)
            }
        }
    }

    private func reindexLibraryInBackground(_ meetings: [Meeting]) {
        let worker = searchIndexWorkQueue
        Task { await worker.enqueue(meetings) }
    }

    private var notesEmbeddingDebounce: [Meeting.ID: Task<Void, Never>] = [:]

    /// The user's own notes are keyword- and meaning-searchable. Re-embedding
    /// a whole meeting is expensive, so it waits for typing to settle.
    func meetingNotesDidChange(_ meeting: Meeting) {
        reindexSearchInBackground(meeting)
        guard settings.semanticSearchEnabled else { return }
        notesEmbeddingDebounce[meeting.id]?.cancel()
        notesEmbeddingDebounce[meeting.id] = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(20))
            guard !Task.isCancelled, let self else { return }
            self.notesEmbeddingDebounce[meeting.id] = nil
            self.reindexEmbeddingInBackground(meeting)
        }
    }

    private func reindexSearchInBackground(_ meeting: Meeting) {
        let worker = searchIndexWorkQueue
        Task { await worker.enqueue(meeting) }
    }

    private func reindexEmbeddingLibraryInBackground(_ meetings: [Meeting]) {
        embeddingBackfillTask?.task.cancel()
        let token = UUID()
        let task = Task { @MainActor [weak self] in
            guard let self, !Task.isCancelled else { return }
            await self.embeddingIndex.reindexAll(meetings) { [weak self] done, total in
                guard let self, self.embeddingBackfillTask?.token == token else { return }
                self.embeddingBackfill = BackgroundCount(done: done, total: total)
            }
            guard self.embeddingBackfillTask?.token == token else { return }
            self.embeddingBackfillTask = nil
            self.embeddingBackfill = nil
        }
        embeddingBackfillTask = (token, task)
    }

    private func reindexEmbeddingInBackground(_ meeting: Meeting) {
        embeddingIndexTasks.removeValue(forKey: meeting.id)?.task.cancel()
        let token = UUID()
        let task = Task { @MainActor [weak self] in
            guard let self, !Task.isCancelled else { return }
            try? await self.embeddingIndex.index(meeting)
            guard self.embeddingIndexTasks[meeting.id]?.token == token else { return }
            self.embeddingIndexTasks.removeValue(forKey: meeting.id)
        }
        embeddingIndexTasks[meeting.id] = (token, task)
    }

    /// Index rows are reconstructible, but a failed SQLite cleanup must not
    /// become permanent once the meeting folder disappears. Retry both stores
    /// with bounded backoff for the rest of the session; durable tombstones and
    /// each index's startup reconciliation cover interruption or app exit.
    private func scheduleIndexCleanup(_ meetingID: Meeting.ID) {
        indexCleanupTasks.removeValue(forKey: meetingID)?.task.cancel()
        let token = UUID()
        let worker = searchIndexWorkQueue
        let task = Task { @MainActor [weak self] in
            guard let self else { return }
            var embeddingClean = false
            var searchClean = false
            var attempt = 0

            while !Task.isCancelled {
                let result = await worker.remove(meetingID)
                embeddingClean = embeddingClean || result.embedding
                searchClean = searchClean || result.search
                guard !Task.isCancelled,
                      self.indexCleanupTasks[meetingID]?.token == token else { return }
                if embeddingClean && searchClean {
                    self.indexCleanupTasks.removeValue(forKey: meetingID)
                    return
                }

                attempt += 1
                if attempt.isMultiple(of: 4) {
                    let reconciled = await worker.reconcileDeletedMeetings()
                    embeddingClean = embeddingClean || reconciled.embedding
                    searchClean = searchClean || reconciled.search
                }
                let delayMilliseconds = min(30_000, 250 * (1 << min(attempt, 7)))
                try? await Task.sleep(for: .milliseconds(delayMilliseconds))
            }
        }
        indexCleanupTasks[meetingID] = (token, task)
    }

    private enum CotypingRuntimeOperation {
        case unload
        case prewarm
    }

    private func scheduleCotypingRuntimeUnload() {
        scheduleCotypingRuntimeOperation(.unload)
    }

    private func scheduleCotypingPrewarm() {
        scheduleCotypingRuntimeOperation(.prewarm)
    }

    /// Queue lifecycle changes instead of launching independent tasks. An
    /// unload intentionally runs even if a later operation cancels its task:
    /// the later operation awaits it before loading another model.
    private func scheduleCotypingRuntimeOperation(_ operation: CotypingRuntimeOperation) {
        let previous = cotypingRuntimeTask
        previous?.cancel()
        let taskID = UUID()
        cotypingRuntimeTaskID = taskID
        cotypingRuntimeTask = Task { @MainActor [weak self] in
            if let previous { await previous.value }
            guard let self else { return }
            defer {
                if self.cotypingRuntimeTaskID == taskID {
                    self.cotypingRuntimeTask = nil
                    self.cotypingRuntimeTaskID = nil
                }
            }
            switch operation {
            case .unload:
                await self.cotypingEngine.unload()
            case .prewarm:
                guard !Task.isCancelled, self.settings.cotypingEnabled else { return }
                await self.cotypingEngine.prewarm()
            }
        }
    }

    func prepareForTermination() async -> Bool {
        if let terminationCleanupTask {
            return await terminationCleanupTask.value
        }
        let task = Task { @MainActor in
            // Keep the application usable when a stopped recording still has
            // unsaved metadata or processing intent. A later Quit retries it.
            guard recording.prepareForTermination() else { return false }
            interactive = false
            settingsStore.flush()
            let pendingCotypingRuntimeTask = self.cotypingRuntimeTask
            pendingCotypingRuntimeTask?.cancel()
            await pendingCotypingRuntimeTask?.value
            self.cotypingRuntimeTask = nil
            cotypingRuntimeTaskID = nil
            libraryLoadTask?.cancel()
            libraryLoadTask = nil
            embeddingBackfillTask?.task.cancel()
            embeddingBackfillTask = nil
            embeddingBackfill = nil
            for entry in embeddingIndexTasks.values { entry.task.cancel() }
            embeddingIndexTasks.removeAll()
            for entry in indexCleanupTasks.values { entry.task.cancel() }
            indexCleanupTasks.removeAll()
            await searchIndexWorkQueue.stop()
            pendingRecordingStart = nil
            detector.stop()
            audioMonitor.stop()
            sampler.stop()
            screenshots.stop()
            quickRecallHotKey.stop()
            dailyMemoryExportScheduler.stop()
            memoryRoutines.stop()
            dreaming.stop()
            chat.stop()
            dictation.stop()
            cotyping.stop()
            await cotypingLearning.flushPersistence()
            await CotypingStatsStore.shared.flushPersistence()
            await agentSessions.shutdownAll()
            await cotypingEngine.unload()
            await LlamaServer.shared.stop()
            await LlamaServer.embedder.stop()
            await LlamaServer.cotyping.stop()
            await GraniteSpeechEngine.shared.shutdown()
            return true
        }
        terminationCleanupTask = task
        let completed = await task.value
        if !completed { terminationCleanupTask = nil }
        return completed
    }

    // MARK: - Detection → recording glue

    /// Builds a detection context for a user-initiated recording on `detectedApp`
    /// (nil → manual), folding in the active calendar event when calendar
    /// detection is enabled and authorized — so menu and command entry points
    /// get calendar titling too.
    func recordingContext(for detectedApp: MeetingDetector.DetectedApp?) -> MeetingDetectionContext? {
        guard let detectedApp else { return nil }
        let event = (settings.calendarDetectionEnabled && calendar.hasAccess)
            ? calendar.activeCandidate(now: Date()) : nil
        return MeetingDetectionContext(
            detectedApp: detectedApp,
            calendarEvent: event,
            confidence: MeetingMatcher.confidence(hasApp: true, hasCalendar: event != nil),
            reason: "user",
            detectorSessionID: detectorSession(following: detectedApp))
    }

    /// A recording the user starts for the call the detector is tracking joins
    /// that session, so the call's end stops it. Manual mode leaves every stop
    /// to the user.
    private func detectorSession(following detectedApp: MeetingDetector.DetectedApp?) -> UUID? {
        guard settings.autoRecordMode != .manual, let detectedApp, detectedApp == detector.activeApp else { return nil }
        return detector.activeSessionID
    }

    /// A user can explicitly start the scheduled event from Today's upcoming
    /// meeting card before automatic detection fires. Attach the calendar
    /// metadata immediately; capture system audio too when a matching meeting
    /// app is already visible, otherwise RecordingController safely records
    /// the microphone when no meeting app is visible yet.
    func recordingContext(for calendarEvent: CalendarMeetingCandidate) -> MeetingDetectionContext {
        let detectedApp = detector.activeApp ?? MeetingDetector.visibleBrowserMeeting()
        return MeetingDetectionContext(
            detectedApp: detectedApp,
            calendarEvent: calendarEvent,
            confidence: MeetingMatcher.confidence(
                hasApp: detectedApp != nil,
                hasCalendar: true),
            reason: "today-upcoming",
            detectorSessionID: detectorSession(following: detectedApp))
    }

    /// `AudioSourceMonitor` saw an app newly start producing output. Auto-record
    /// in automatic mode only for high-confidence native meeting output or a
    /// verified browser meeting; ignore broader candidates so notification
    /// sounds cannot start recordings.
    private func audioMonitorDetected(_ process: AudioProcess) {
        guard !recording.isRecording, !recording.isStarting else { return }
        guard settings.autoRecordMode == .automatic, let bundleID = process.bundleID else { return }
        let calendarEvent = (settings.calendarDetectionEnabled && calendar.hasAccess)
            ? calendar.activeCandidate(now: Date()) : nil
        if let name = MeetingDetector.knownApps[bundleID] {
            guard MeetingDetector.shouldAutoRecordNativeAudioMonitor(
                bundleID: bundleID,
                calendarBacked: calendarEvent != nil) else {
                return
            }
            let detected = MeetingDetector.DetectedApp(name: name, bundleID: bundleID, pid: process.id)
            detector.acceptNativeAudioStart(app: detected, calendarEvent: calendarEvent)
            return
        }
        guard MeetingDetector.hostBrowserBundleID(forAudioBundleID: bundleID) != nil else { return }
        detector.checkNow()
    }

    private func notifyMeetingDetected(_ context: MeetingDetectionContext) {
        lastError = nil
        let title = MeetingMatcher.recordingTitle(
            calendarTitle: context.calendarEvent?.title,
            useCalendarTitles: settings.useCalendarTitles,
            appName: context.detectedApp?.name)
        RecordingNotifier.shared.meetingDetected(title: title, onUnavailable: { [weak self] in
            guard let self, self.settings.autoRecordMode == .ask,
                  context.detectorSessionID == self.detector.activeSessionID,
                  !self.recording.isRecording, !self.recording.isStarting else { return }
            self.lastError = "Notifications are unavailable. Choose Record now in the LokalBot menu to record \(title)."
        }) { [weak self] in
            guard let self,
                  self.settings.autoRecordMode == .ask,
                  context.detectorSessionID == self.detector.activeSessionID,
                  !self.recording.isRecording,
                  !self.recording.isStarting else { return }
            self.startRecording(context: context, source: "notification")
        }
    }

    // MARK: - Library operations

    /// Creates a new, provenance-linked meeting from completed sources. The
    /// source folders remain untouched, but their rows are folded out of the
    /// library after the merge succeeds.
    func mergeMeetings(
        _ sourceMeetings: [Meeting],
        title: String,
        generateSummary: Bool
    ) async throws -> Meeting {
        for meeting in sourceMeetings {
            if let stage = pipeline.stages[meeting.id], !stage.isFailure {
                throw MeetingMergeService.MergeError.processingInProgress(meeting.displayTitle)
            }
        }
        // Folding can partially write before rollback fails. Reopen derived
        // consumers even when merge cannot return a complete result.
        defer { primaryEvidenceDidChange(for: sourceMeetings) }
        let result = try await MeetingMergeService.merge(
            meetings: sourceMeetings,
            title: title,
            storage: storage)

        let sourceIDs = Set(result.sourceMeetings.map(\.id))
        await pipeline.forget(meetingIDs: sourceIDs)
        let worker = searchIndexWorkQueue
        for sourceID in sourceIDs {
            embeddingIndexTasks.removeValue(forKey: sourceID)?.task.cancel()
            excludedMeetingIDs.insert(sourceID)
            cachedSearchIndex?.noteDeletion(sourceID)
            cachedEmbeddingIndex?.noteDeletion(sourceID)
            // Tombstone both indexes before publishing the folded library
            // projection. The retry loop remains available for a transient
            // SQLite failure, but a normal merge cannot leave searchable
            // source rows behind if the app exits immediately afterward.
            let cleanup = await worker.remove(sourceID)
            if !cleanup.search || !cleanup.embedding {
                scheduleIndexCleanup(sourceID)
            }
        }
        meetings.removeAll { sourceIDs.contains($0.id) }
        selectedMeetingIDs.subtract(sourceIDs)
        meetings.append(result.meeting)
        meetings.sort { $0.startedAt > $1.startedAt }
        outcomeIndex.refresh(meetings: meetings)
        primaryEvidenceDidChange(for: result.sourceMeetings + [result.meeting])
        reindexSearchInBackground(result.meeting)
        if settings.semanticSearchEnabled {
            reindexEmbeddingInBackground(result.meeting)
        }
        selectedMeetingIDs = [result.meeting.id]
        navSection = .meetings
        if generateSummary {
            // A partial merged transcript must never satisfy the summary
            // request. Re-transcribe the concatenated audio so every source
            // range is represented; this also handles two audio-only sources.
            reprocess(
                result.meeting,
                transcribe: !result.transcriptCoverageComplete,
                summarize: true)
        }
        return result.meeting
    }

    /// Removes a generated merged record and restores its original source
    /// rows. Source folders are retained; their durable merge markers and
    /// search tombstones are cleared before the restored evidence is indexed.
    func undoMerge(_ mergedMeeting: Meeting) {
        guard let rawSourceIDs = mergedMeeting.mergedSourceMeetingIDs,
              rawSourceIDs.count >= 2 else {
            lastError = "This meeting does not contain a reversible merge."
            return
        }
        if let stage = pipeline.stages[mergedMeeting.id], !stage.isFailure {
            lastError = "Wait for the merged summary to finish before undoing the merge."
            return
        }

        let sourceIDs = Set(rawSourceIDs)
        let sources: [Meeting]
        do {
            // Enumeration during a live session must never run startup orphan repair.
            sources = try SessionLookup.loadAllMeetings(root: storage.rootURL, includeMergedSources: true)
                .filter { sourceIDs.contains($0.id) }
        } catch {
            lastError = "Could not read the original meetings: \(error.localizedDescription)"
            return
        }
        guard sources.count == sourceIDs.count,
              sources.allSatisfy({ $0.mergedIntoMeetingID == mergedMeeting.id }) else {
            lastError = "Some original meetings could not be found, so the merge was kept intact."
            return
        }

        lastError = nil
        let worker = searchIndexWorkQueue
        Task { @MainActor [weak self] in
            guard let self else { return }
            do {
                await pipeline.forget(meetingIDs: [mergedMeeting.id])
                try await speakerIdentity.prepareDeletion(meeting: mergedMeeting)
                try withPrimaryEvidenceChange(for: [mergedMeeting]) {
                    try self.storage.deleteMeeting(mergedMeeting)
                }
                meetings.removeAll { $0.id == mergedMeeting.id }
                selectedMeetingIDs.remove(mergedMeeting.id)
                outcomeIndex.refresh(meetings: meetings)

                embeddingIndexTasks.removeValue(forKey: mergedMeeting.id)?.task.cancel()
                excludedMeetingIDs.insert(mergedMeeting.id)
                cachedSearchIndex?.noteDeletion(mergedMeeting.id)
                cachedEmbeddingIndex?.noteDeletion(mergedMeeting.id)
                scheduleIndexCleanup(mergedMeeting.id)

                var restoredSources: [Meeting] = []
                var restorationErrors: [String] = []
                for source in sources {
                    indexCleanupTasks.removeValue(forKey: source.id)?.task.cancel()
                    do {
                        let restored = try await worker.restore(source)
                        restoredSources.append(restored)
                        pipeline.restoreForgottenMeetings([source.id])
                        excludedMeetingIDs.remove(source.id)
                        cachedSearchIndex?.noteRestoration(source.id)
                        cachedEmbeddingIndex?.noteRestoration(source.id)
                        if settings.semanticSearchEnabled {
                            reindexEmbeddingInBackground(restored)
                        }
                    } catch {
                        // Other sources can still recover. Failed ones retain
                        // their on-disk marker and are retried at next launch.
                        restorationErrors.append(error.localizedDescription)
                    }
                }
                meetings.append(contentsOf: restoredSources)
                meetings.sort { $0.startedAt > $1.startedAt }
                outcomeIndex.refresh(meetings: meetings)
                primaryEvidenceDidChange(for: [mergedMeeting] + restoredSources)
                selectedMeetingIDs = restoredSources
                    .sorted { $0.startedAt < $1.startedAt }
                    .first.map { [$0.id] } ?? []
                navSection = .meetings
                if !restorationErrors.isEmpty {
                    lastError = "Some original meetings could not be restored; restart to retry: "
                        + restorationErrors.joined(separator: "; ")
                }
            } catch {
                if FileManager.default.fileExists(
                    atPath: mergedMeeting.folderURL(in: storage).path) {
                    pipeline.restoreForgottenMeetings([mergedMeeting.id])
                }
                lastError = "Could not undo the merge: \(error.localizedDescription)"
            }
        }
    }

    func setMeetingBoundaries(_ range: Meeting.ContentRange, for meeting: Meeting) throws {
        if let stage = pipeline.stages[meeting.id], !stage.isFailure {
            throw TextEngineError.badResponse("Wait for meeting processing to finish before changing its boundaries.")
        }
        guard range.isValid, let duration = meeting.recordedDuration ?? meeting.duration,
              range.end <= duration else {
            throw TextEngineError.badResponse("Choose a start and end within the recorded audio, with the end after the start.")
        }
        var updated = meeting
        updated.contentRange = range
        updated.contentRangeSource = .userReviewed
        let folder = updated.folderURL(in: storage)
        let existing = try pipeline.loadTranscript(from: folder)
        // Invalidate derived claims even when no complete segment survives.
        try withPrimaryEvidenceChange(for: [updated]) {
            try MeetingAttributionArtifacts.invalidate(in: folder)
            try pipeline.saveTranscript(range.applying(to: existing), for: updated)
            try storage.saveMeta(updated)
        }
        if let index = meetings.firstIndex(where: { $0.id == updated.id }) { meetings[index] = updated }
        outcomeIndex.refresh(meeting: updated)
        primaryEvidenceDidChange(for: updated)
        searchIndex.reindex(updated, storage: storage)
        embeddingIndexTasks.removeValue(forKey: updated.id)?.task.cancel()
        embeddingIndex.clearVectors(for: updated.id)
        reprocess(updated, transcribe: true, summarize: true)
    }

    func reprocess(_ meeting: Meeting, transcribe: Bool, summarize: Bool) {
        lastError = nil
        switch pipeline.enqueue(
            meeting,
            transcribe: transcribe,
            summarize: summarize) {
        case .alreadyProcessing:
            lastError = "Summary processing has already started for this meeting. Wait for it to finish before choosing a different processing action."
        case .persistenceFailed:
            lastError = "LokalBot could not save the updated processing request."
        case .revoked:
            lastError = "This meeting is being removed and can no longer be processed."
        case .enqueued, .coalesced, .updatedActive:
            break
        }
    }

    /// Resume from the latest durable artifact. If transcription already
    /// succeeded, Retry fixes only summarization; missing transcripts still run
    /// the complete pipeline. User-initiated work may download missing models.
    func retryProcessing(_ meeting: Meeting) {
        let work = pipeline.retryWork(
            for: meeting, autoSummarize: settings.autoSummarize)
        reprocess(meeting, transcribe: work.transcribe, summarize: work.summarize)
    }

    /// Meetings parked because a model was missing re-enter the queue; jobs
    /// whose models are still missing simply park again — nothing downloads
    /// from this path.
    func processMeetingsWaitingForModels() {
        pipeline.retryJobsWaitingForModels()
    }

    func saveTranscript(_ transcript: Transcript, for meeting: Meeting) throws {
        let transcript = speakerIdentity.applyingLatestDecision(to: transcript, meetingID: meeting.id)
        try withPrimaryEvidenceChange(for: [meeting]) {
            try pipeline.saveTranscript(transcript, for: meeting)
        }
        outcomeIndex.refresh(meeting: meeting)
        primaryEvidenceDidChange(for: meeting)
        reindexSearchInBackground(meeting)
        if settings.semanticSearchEnabled {
            reindexEmbeddingInBackground(meeting)
        }
        objectWillChange.send()
    }

    func speakerNameHints(for meeting: Meeting) -> [String] {
        let fallbackDuration = max(meeting.recordedDuration ?? 60, 60)
        let fallbackEnd = meeting.startedAt.addingTimeInterval(fallbackDuration)
        var end = meeting.endedAt.map { max($0, meeting.startedAt) } ?? fallbackEnd
        if end <= meeting.startedAt { end = fallbackEnd }
        let ocr = activityStore.ocrText(from: meeting.startedAt, to: end, maxChars: 12_000)
        return SpeakerNameHintExtractor.hints(
            calendarNames: meeting.resolvedCalendarParticipantIdentities.compactMap(\.name),
            ocrText: ocr)
    }

    private var dictationVocabularyCache: (key: String, terms: [String])?

    /// Dictation has no meeting of its own, so prompt-capable speech models
    /// receive recent attendee and project names beside the manual vocabulary.
    func dictationTranscriptionSettings(_ base: AppSettings) -> AppSettings {
        guard base.autoTranscriptionVocabulary,
              base.transcriptionModel.acceptsVocabularyPrompt else { return base }
        let dayKey = DreamDay.key(for: Date())
        let key = "\(dayKey)|\(meetings.count)|\(meetings.map(\.startedAt).max()?.timeIntervalSince1970 ?? 0)"
        let terms: [String]
        if let cached = dictationVocabularyCache, cached.key == key {
            terms = cached.terms
        } else {
            let memory = (try? dreamStore.loadMemory()) ?? nil
            terms = TranscriptionVocabulary.terms(
                TranscriptionVocabulary.recentSources(library: meetings, memory: memory))
            dictationVocabularyCache = (key, terms)
        }
        var settings = base
        settings.transcriptionPrompt = TranscriptionVocabulary.prompt(
            manual: base.transcriptionPrompt, terms: terms)
        return settings
    }

    /// One invalidation route for every meeting-evidence write. Processing and
    /// user outcome edits both reach this path, so derived Digest, Dream,
    /// export, and routine surfaces cannot silently diverge.
    private func primaryEvidenceDidChange(for meeting: Meeting) {
        primaryEvidenceDidChange(for: [meeting])
    }

    private func primaryEvidenceDidChange(for meetings: [Meeting]) {
        primaryEvidenceDidChange(on: meetings.map(\.startedAt), meetingIDs: Set(meetings.map(\.id)))
    }

    func primaryEvidenceDidChange(on day: Date) {
        primaryEvidenceDidChange(on: [day])
    }

    func primaryEvidenceDidChange(on days: [Date]) {
        primaryEvidenceDidChange(on: days, meetingIDs: [])
    }

    private func primaryEvidenceDidChange(on days: [Date], meetingIDs: Set<UUID>) {
        guard !days.isEmpty else { return }
        dayDigest.reconsiderEvidence(for: days)
        dailyMemoryExportScheduler.reconsider(days: days)
        memoryRoutines.reconsiderEvidence()
        // Meetings feed later days' comparison windows; screen, activity, and
        // coding-agent evidence is read only for its own day. Treating a
        // screen change as a meeting change made every retention pass
        // discard two weeks of Dream reports.
        let activityOnly = meetingIDs.isEmpty
        invalidateDreams(affectedDays: days, affectedMeetingIDs: meetingIDs,
                         comparisonWindowDays: activityOnly ? 1 : DreamCompiler.comparisonWindowDays,
                         activityOnly: activityOnly)
    }

    func withPrimaryEvidenceChange<T>(on days: [Date], _ mutation: () throws -> T) throws -> T {
        if settings.cotypingUseMeetingMemory || settings.cotypingUseScreenMemory { cotyping.invalidateMemoryContext() }
        defer { primaryEvidenceDidChange(on: days) }
        purgeDigestSegmentAnswers(for: days)
        return try dreamStore.withScreenEvidenceMutation(on: days) {
            try dayDigest.retractGeneratedJournals(for: days)
            return try mutation()
        }
    }

    /// Scheduled retention expires screen text, titles, and agent sessions on
    /// their own clock; nobody deleted or corrected them. Generated journals
    /// still retract with their evidence (PRIVACY.md), but Dream reports and
    /// work memory are long-term memory: they outlive the screen window and
    /// go only when a source is deleted or corrected, or the memory is cleared.
    /// Before, every pass wiped nearly all of it, because each memory change
    /// inherits the sources of every other item.
    func withScheduledRetention<T>(on days: [Date], _ mutation: () throws -> T) throws -> T {
        defer { scheduledRetentionDidRemoveEvidence(on: days) }
        purgeDigestSegmentAnswers(for: days)
        try dayDigest.retractGeneratedJournals(for: days)
        return try mutation()
    }

    private func scheduledRetentionDidRemoveEvidence(on days: [Date]) {
        guard !days.isEmpty else { return }
        dayDigest.reconsiderEvidence(for: days)
        dailyMemoryExportScheduler.reconsider(days: days)
        memoryRoutines.reconsiderEvidence()
    }

    private func withPrimaryEvidenceChange<T>(for meetings: [Meeting], _ mutation: () throws -> T) throws -> T {
        if settings.cotypingUseMeetingMemory || settings.cotypingUseScreenMemory { cotyping.invalidateMemoryContext() }
        defer { primaryEvidenceDidChange(for: meetings) }
        purgeDigestSegmentAnswers(for: meetings.map(\.startedAt))
        return try dreamStore.withMeetingEvidenceMutation(for: meetings) {
            try dayDigest.retractGeneratedJournals(for: meetings.map(\.startedAt))
            return try mutation()
        }
    }

    /// Deleted or corrected evidence must not survive in reused digest answers.
    private func purgeDigestSegmentAnswers(for days: [Date]) {
        let calendar = Calendar.current
        DayDigestSegmentCache.shared.purge(days: Set(days.map { DreamDay.key(for: $0, calendar: calendar) }))
    }

    private func dayDigestDidChange(on day: Date) {
        // Export may have run while the replacement digest was still awaiting
        // a model. Reopen consumers after the journal and provenance are saved.
        dailyMemoryExportScheduler.reconsider(day: day)
        memoryRoutines.reconsiderEvidence()
        // A dream only reads finished days' digests. Today's digest is
        // refreshed many times a day and no report depends on it yet; a past
        // day's regenerated digest revokes exactly that day's report.
        let calendar = Calendar.current
        guard calendar.startOfDay(for: day) < calendar.startOfDay(for: Date()) else { return }
        invalidateDreams(affectedDays: [day], comparisonWindowDays: 1, activityOnly: true,
                         sourceDayKeys: [DreamDay.key(for: day, calendar: calendar)])
    }

    private func invalidateDreams(
        affectedDays: [Date], affectedMeetingIDs: Set<UUID> = [],
        comparisonWindowDays: Int = DreamCompiler.comparisonWindowDays,
        activityOnly: Bool = false,
        sourceDayKeys: Set<String>? = nil
    ) {
        let calendar = Calendar.current
        let affectedKeys = DreamEvidenceInvalidation.dayKeys(
            affectedDays: affectedDays, through: Date(), calendar: calendar,
            comparisonWindowDays: comparisonWindowDays)
        var invalidatedKeys = affectedKeys
        do {
            invalidatedKeys = try dreamStore.invalidateEvidence(
                affectedDayKeys: sourceDayKeys ?? DreamEvidenceInvalidation.sourceDayKeys(for: affectedDays),
                affectedMeetingIDs: affectedMeetingIDs,
                reportDayKeys: affectedKeys,
                activityOnly: activityOnly)
        } catch {
            lastError = "Could not retract changed evidence from Dream memory: " + error.localizedDescription
        }
        refreshDreamMemory()
        latestDreamReport = dreamStore.latestReport()
        // An in-flight dream is checked against its own sources when it
        // commits, so only a change to the day being dreamed stops it early.
        dreaming.reconsiderReports(invalidating: invalidatedKeys, cancellingInFlight: false)
    }

    func applyTrackingSetting() {
        screenshots.mutateEvidence = { [weak self] days, mutation in
            guard let self else { throw CancellationError() }
            // Only the scheduled retention pass calls this hook; explicit
            // deletions go through `withPrimaryEvidenceChange` directly.
            try self.withScheduledRetention(on: days, mutation)
        }
        sampler.excludedApps = { [weak self] in self?.settings.excludedAppList ?? [] }
        sampler.excludedDomains = { [weak self] in self?.settings.excludedScreenDomainList ?? [] }
        if settings.trackingEnabled { sampler.start() } else { sampler.stop() }
        screenshots.restart()
    }

    func applyQuickRecallSetting() {
        let registered = quickRecallHotKey.setEnabled(settings.quickRecallEnabled)
        if settings.quickRecallEnabled, !registered {
            settings.quickRecallEnabled = false
            lastError = "The Ask shortcut could not register \(QuickRecallHotKeyController.shortcutLabel). Another app may already use it."
        }
    }

    func applyDailyMemoryExportSetting() {
        let snapshot = settings
        let destinationID = snapshot.dailyMemoryExportFolder.isEmpty
            ? ""
            : "\(snapshot.dailyMemoryExportFolder)|\(snapshot.dailyMemoryExportFormat.rawValue)"
        let configuration = DailyMemoryExportScheduler.Configuration(
            enabled: snapshot.dailyMemoryExportEnabled,
            hour: snapshot.dailyMemoryExportHour,
            destinationID: destinationID)
        let storageRoot = storage.rootURL
        let destinationPath = snapshot.dailyMemoryExportFolder
        let exportKind: DailyMemoryExportKind = switch snapshot.dailyMemoryExportFormat {
        case .markdown: .markdown
        case .obsidian: .obsidian
        case .logseq: .logseq
        }
        dailyMemoryExportScheduler.configure(configuration) { day in
            let destination = URL(
                fileURLWithPath: destinationPath,
                isDirectory: true)
            try Task.checkCancellation()
            let service = DailyMemoryExportService(
                source: FileDailyMemoryExportSource(root: storageRoot),
                calendar: .current)
            _ = try service.export(
                day: day,
                configuration: DailyMemoryExportConfiguration(
                    destinationDirectory: destination,
                    format: exportKind))
        } onError: { [weak self] message in
            self?.lastError = message
        }
    }

    /// Starts or stops transcript reading. Turning it off keeps what was
    /// already saved, like the other capture sources; deletion is explicit.
    func applyCodingAgentEvidenceSetting() {
        codingAgentEvidence.start()
    }

    /// New settled work usually lands today, before the evening digest.
    /// Yesterday may already be final, so late work reopens it.
    private func codingAgentEvidenceDidChange(on days: [Date]) {
        let calendar = Calendar.current
        guard let yesterday = calendar.date(
            byAdding: .day, value: -1, to: calendar.startOfDay(for: Date())) else { return }
        let reopened = days.filter { calendar.isDate($0, inSameDayAs: yesterday) }
        if !reopened.isEmpty { dayDigest.reconsiderEvidence(for: reopened) }
    }

    /// Stops reading coding-agent sessions and deletes every saved burst.
    /// The agents' own transcripts are never touched.
    func deleteCodingAgentEvidence() throws {
        settings.codingAgentEvidenceEnabled = false
        let starts = try activityStore.codingAgentBurstStarts()
        guard !starts.isEmpty else { return }
        let days = Array(Set(starts.values.map { Calendar.current.startOfDay(for: $0) }))
        try withPrimaryEvidenceChange(on: days) {
            try activityStore.deleteCodingAgentBursts(ids: Array(starts.keys))
        }
        NotificationCenter.default.post(name: .codingAgentEvidenceChanged, object: nil)
    }

    func applyDayDigestSetting() {
        let snapshot = settings
        dayDigest.stopAutomaticGeneration()
        dayDigest.configureAutomaticGeneration(
            DayDigestScheduler.Configuration(
                enabled: snapshot.dayDigestAutoEnabled,
                hour: snapshot.dayDigestHour),
            canRun: { [weak self] in
                guard let self, self.libraryReady, self.settings.allowsAutomaticMainInference else { return false }
                // Scheduled background work never triggers a model download —
                // the digest waits until the Think model is actually on disk
                // (or a remote backend is configured).
                guard ModelReadinessSnapshot.thinkReady(self.settings, storage: self.storage)
                else { return false }
                let cotypingGenerating: Bool
                if case .generating = self.cotyping.state {
                    cotypingGenerating = true
                } else {
                    cotypingGenerating = false
                }
                return !self.recording.isRecording
                    && !self.recording.isStarting
                    && !self.dictation.isStarting
                    && !self.dictation.state.isWorking
                    && !cotypingGenerating
                    && !self.pipeline.hasActiveWork
            },
            onError: { [weak self] message in
                self?.lastError = message
            })
    }

    private func bindBackgroundActivity() {
        backgroundActivity.bind(.init(
            pipeline: pipeline,
            dayDigest: dayDigest,
            dreaming: dreaming,
            downloads: ModelDownloadManager.shared,
            reindex: $embeddingBackfill.eraseToAnyPublisher(),
            meetingTitle: { [weak self] id in
                self?.meetings.first { $0.id == id }?.displayTitle
            },
            modelName: { [weak self] id in
                ModelCatalog.entry(id: id, custom: self?.settings.customBuiltInModels ?? [])?.displayName ?? id
            }))
    }

    /// Navigate to the screen that owns a background activity.
    func openBackgroundActivity(_ destination: BackgroundActivity.Destination) {
        switch destination {
        case .meeting(let id):
            openMeeting(id)
        case .day(let day):
            if Calendar.current.isDateInToday(day) {
                navSection = .today
            } else {
                openTimelineDay(day)
            }
        case .dream:
            navSection = .today
        case .models:
            openSettings(tab: .models)
        }
    }

    func libraryHealthReport(for day: Date, now: Date = Date()) -> LibraryHealthReport {
        let loader = LibraryHealthLoader(
            activityStore: activityStore,
            storageRoot: storage.rootURL,
            meetings: meetings,
            queuedMeetingIDs: pipeline.queuedMeetingIDs(),
            settings: settings,
            hasDreamReport: { [dreamStore] in dreamStore.hasReport(forDayKey: $0) })
        return LibraryHealthEvaluator.evaluate(
            loader.input(for: day, now: now), dayKey: DreamDay.key(for: day))
    }

    private(set) lazy var healthScheduler = LibraryHealthScheduler()

    /// Evaluates yesterday, writes the report, and notifies on failure.
    @discardableResult
    func runHealthCheckNow(notify: Bool = true) -> URL? {
        let calendar = Calendar.current
        let yesterday = calendar.date(byAdding: .day, value: -1, to: calendar.startOfDay(for: Date())) ?? Date()
        let report = libraryHealthReport(for: yesterday)
        do {
            let url = try LibraryHealthReportStore.write(report, root: storage.rootURL)
            if notify, report.status == .fail {
                let failed = report.findings.filter { $0.status == .fail }.map(\.check.title)
                RecordingNotifier.shared.healthCheckFailed(
                    summary: failed.joined(separator: ", "), reportURL: url)
            }
            return url
        } catch {
            lokalbotLog("health report write failed: \(error.localizedDescription)")
            return nil
        }
    }

    func applyHealthCheckSetting() {
        guard LibraryHealthScheduler.isEnabledForThisBuild else { return }
        let root = storage.rootURL
        healthScheduler.start(
            lastRun: { LibraryHealthReportStore.latestRunDate(root: root) },
            run: { [weak self] in self?.runHealthCheckNow() })
    }

    func diagnosticsSources() -> DiagnosticsExporter.Sources {
        let log = AppLog.debugLogURL()
        let root = storage.rootURL
        return DiagnosticsExporter.Sources(
            logURLs: [log] + FileLogSink.rotatedURLs(for: log, maxRotations: 5),
            healthReportsDirectory: DiagnosticsPaths.healthReports(root: root),
            captureTracesDirectory: DiagnosticsPaths.captureTraces(root: root),
            databaseURL: DiagnosticsPaths.database(root: root),
            settingsJSON: try? JSONEncoder().encode(settings))
    }

    @discardableResult
    func exportDiagnostics(to destination: URL) throws -> DiagnosticsExporter.Manifest {
        try DiagnosticsExporter.export(diagnosticsSources(), to: destination)
    }

#if DEBUG
    /// Debug menu: records the live capture environment for `seconds`, then
    /// writes a scrubbed trace to diagnostics/capture-traces and reveals it.
    func startCaptureTraceRecording(seconds: Int = 60, scenario: String = "real") {
        guard CaptureTraceRecorder.active == nil else {
            lokalbotLog("capture trace: a recording is already running")
            return
        }
        let recorder = CaptureTraceRecorder(scenario: scenario, origin: scenario == "real" ? .real : .scripted)
        CaptureTraceRecorder.active = recorder
        CaptureEnvironment.install(recorder.environment)
        lokalbotLog("capture trace: recording \(seconds)s")
        Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(seconds))
            CaptureEnvironment.reset()
            CaptureTraceRecorder.active = nil
            guard let self else { return }
            do {
                let url = try recorder.finish(to: DiagnosticsPaths.captureTraces(root: self.storage.rootURL))
                lokalbotLog("capture trace: wrote \(url.lastPathComponent)")
                NSWorkspace.shared.activateFileViewerSelecting([url])
            } catch {
                lokalbotLog("capture trace: FAILED — \(error.localizedDescription)")
            }
        }
    }
#endif

    /// Open Timeline on a local day, e.g. to read that day's digest.
    func openTimelineDay(_ day: Date) {
        navigationHandoff.stageTimelineDay(day)
        selectedMeetingIDs = []
        navSection = .timeline
    }

    func applyMemoryRoutineSetting() {
        let snapshot = settings
        memoryRoutines.configure(MemoryRoutineScheduler.Configuration(
            enabled: snapshot.memoryRoutinesEnabled,
            destinationPath: snapshot.memoryRoutineFolder,
            kinds: snapshot.enabledMemoryRoutines,
            hour: snapshot.memoryRoutineHour,
            weekday: snapshot.memoryRoutineWeekday
        )) { [weak self] message in
            self?.lastError = message
        }
    }

    func applyDreamingSetting() {
        let snapshot = settings
        dreaming.stop()

        // Persist the beginning of each opt-in period. This keeps catch-up
        // bounded instead of interpreting a first launch as permission to
        // backfill every historical workday.
        if snapshot.dreamingEnabled,
           snapshot.dreamingFirstEligibleDayKey?.isEmpty != false {
            let calendar = Calendar.current
            var updated = snapshot
            updated.dreamingFirstEligibleDayKey = DreamDay.key(
                for: DreamScheduler.previousDay(of: Date(), calendar: calendar),
                calendar: calendar)
            settings = updated
            return
        }

        if !snapshot.dreamingEnabled,
           snapshot.dreamingFirstEligibleDayKey != nil {
            var updated = snapshot
            updated.dreamingFirstEligibleDayKey = nil
            settings = updated
            return
        }

        let storageRoot = storage.rootURL
        dreaming.configure(
            DreamScheduler.Configuration(
                enabled: snapshot.dreamingEnabled,
                hour: snapshot.dreamingHour,
                firstEligibleDayKey: snapshot.dreamingFirstEligibleDayKey ?? ""),
            hasReport: { dayKey in
                DreamStore(root: storageRoot).hasReport(forDayKey: dayKey)
            },
            canRun: { [weak self] in
                guard let self else { return false }
                guard self.libraryReady else { return false }
                guard self.settings.allowsAutomaticMainInference else { return false }
                // Overnight dreaming is background automation: never let it
                // trigger a model download on a fresh install.
                guard ModelReadinessSnapshot.thinkReady(self.settings, storage: self.storage)
                else { return false }
                let cotypingGenerating: Bool
                if case .generating = self.cotyping.state {
                    cotypingGenerating = true
                } else {
                    cotypingGenerating = false
                }
                let lokalBotIsIdle = !self.recording.isRecording
                    && !self.recording.isStarting
                    && !self.dictation.isStarting
                    && !self.dictation.state.isWorking
                    && !cotypingGenerating
                    && !self.pipeline.hasActiveWork
                guard lokalBotIsIdle else { return false }
                return DreamScheduler.powerAllowsDreaming(
                    isOnBattery: PowerSourceMonitor.currentlyOnBattery())
            },
            dream: { [weak self] target in
                guard let self else {
                    throw TextEngineError.unavailable("LokalBot is shutting down.")
                }
                let service = DreamService(
                    storageRoot: storageRoot,
                    makeEngine: { [weak self] in
                        guard let self else {
                            throw TextEngineError.unavailable("LokalBot is shutting down.")
                        }
                        let engineSettings = self.settings
                        if target.isAutomatic && !engineSettings.allowsAutomaticMainInference {
                            throw TextEngineError.unavailable("Approve scheduled context sharing for this remote Think server in Models settings.")
                        }
                        let engine = try await self.thinkExecution.makeTextEngine(
                            engineSettings,
                            priority: .background,
                            purpose: "dreaming")
                        try Task.checkCancellation()
                        if target.isAutomatic && !self.settings.allowsAutomaticMainInference {
                            throw CancellationError()
                        }
                        return (engine, DreamInferenceProvenance(settings: engineSettings))
                    })
                let report = try await service.dream(target: target)
                self.latestDreamReport = report
                self.refreshDreamMemory()
            },
            onError: { [weak self] message in
                self?.lastError = message
            })
    }

    func setDreamingEnabled(_ enabled: Bool) {
        guard settings.dreamingEnabled != enabled else { return }

        var updated = settings
        updated.dreamingEnabled = enabled
        if enabled {
            let calendar = Calendar.current
            updated.dreamingFirstEligibleDayKey = DreamDay.key(
                for: DreamScheduler.previousDay(of: Date(), calendar: calendar),
                calendar: calendar)
        } else {
            updated.dreamingFirstEligibleDayKey = nil
        }
        settings = updated
    }

    func dreamNow() {
        guard libraryReady else {
            lastError = "Preparing your meeting library; dreaming will be available when it is ready."
            return
        }
        dreaming.dreamNow()
    }

    func refreshDreamMemory() {
        if settings.cotypingUseMeetingMemory || settings.cotypingUseScreenMemory { cotyping.invalidateMemoryContext() }
        do {
            dreamMemory = try dreamStore.loadMemory()
        } catch {
            dreamMemory = nil
            lastError = "Could not load dream memory: \(error.localizedDescription)"
        }
    }

    /// Settings' "Clear work memory": stops a dream in progress, deletes every
    /// report and the work memory, and dreams only from today on, so the week
    /// before the clear is not re-dreamed straight back into memory.
    func clearDreamMemory() {
        dreaming.stop()
        do {
            try dreamStore.clearAll()
        } catch {
            lastError = "Could not clear dream memory: \(error.localizedDescription)"
        }
        latestDreamReport = nil
        refreshDreamMemory()
        let today = DreamDay.key(for: Date(), calendar: .current)
        if settings.dreamingEnabled, settings.dreamingFirstEligibleDayKey != today {
            var updated = settings
            updated.dreamingFirstEligibleDayKey = today
            settings = updated  // reapplies the schedule through the settings observer
        } else {
            applyDreamingSetting()
        }
    }

    func setDreamMemoryPinned(_ pinned: Bool, for entry: DreamMemoryEntry) {
        guard !dreaming.isDreaming else {
            lastError = "Wait for the current dream to finish before changing pins."
            return
        }
        do {
            guard let updated = try dreamStore.setPinned(pinned, for: entry) else {
                refreshDreamMemory()
                lastError = "That dream memory item is no longer available."
                return
            }
            dreamMemory = updated
        } catch {
            lastError = "Could not update dream memory: \(error.localizedDescription)"
        }
    }

    func restartMemoryCapture() {
        sampler.stop()
        screenshots.stop()
        applyTrackingSetting()
        PermissionManager.shared.refresh()
    }

    /// Search hit → open the meeting; transcript hits seek the player.
    func openSearchHit(_ hit: SearchIndex.Hit) {
        openMeeting(
            hit.meetingID,
            seek: hit.kind == .segment ? hit.start : nil)
    }

    /// Screen search/citation hit → open Timeline at the exact captured frame.
    func openScreenSnapshot(_ snapshotID: Int64) {
        if navSection != .timeline {
            evidenceReturnSection = navSection
            evidenceReturnMeetingIDs = selectedMeetingIDs
        }
        navigationHandoff.stageScreenSnapshot(snapshotID)
        selectedMeetingIDs = []
        navSection = .timeline
    }

    /// Chat citation marker → open the cited meeting; timed markers seek the player.
    func openCitation(_ citation: ChatCitation) {
        guard let meeting = ((try? SessionLookup.find(id: citation.meetingID, in: meetings)) ?? nil) else { return }
        openMeeting(meeting.id, seek: citation.seconds)
    }

    /// Permanently removes meetings: audio folder, list entry, both indexes.
    func deleteMeetings(_ ids: Set<Meeting.ID>) {
        let candidates = meetings.filter { ids.contains($0.id) }
        Task {
            var deletedIDs: Set<Meeting.ID> = []
            var deletedMeetings: [Meeting] = []
            for meeting in candidates {
                var forgottenIDs: Set<Meeting.ID> = []
                do {
                    let ordered = try storage.deletionOrder(for: meeting)
                    forgottenIDs = Set(ordered.map(\.id))
                    await pipeline.forget(meetingIDs: forgottenIDs)
                    for item in ordered where !deletedIDs.contains(item.id) {
                        // Revoke every retained source's profile contributions,
                        // not just those of the generated parent. Delete the
                        // parent last so partial failure cannot restore sources.
                        try await speakerIdentity.prepareDeletion(meeting: item)
                        try withPrimaryEvidenceChange(for: [item]) {
                            try storage.deleteMeeting(item)
                        }
                        embeddingIndexTasks.removeValue(forKey: item.id)?.task.cancel()
                        excludedMeetingIDs.insert(item.id)
                        cachedSearchIndex?.noteDeletion(item.id)
                        cachedEmbeddingIndex?.noteDeletion(item.id)
                        scheduleIndexCleanup(item.id)
                        deletedIDs.insert(item.id)
                        deletedMeetings.append(item)
                    }
                } catch {
                    pipeline.restoreForgottenMeetings(
                        forgottenIDs.subtracting(deletedIDs))
                    lastError = "Could not delete \(meeting.title); cleanup pending: \(error.localizedDescription)"
                }
            }
            meetings.removeAll { deletedIDs.contains($0.id) }
            recording.forgetFinalization(meetingIDs: deletedIDs)
            selectedMeetingIDs.subtract(deletedIDs)
            outcomeIndex.refresh(meetings: meetings)
            primaryEvidenceDidChange(for: deletedMeetings)
        }
    }
}
