import sys, pathlib, json, contextlib, tempfile, plistlib, subprocess, uuid
repo=pathlib.Path('/private/tmp/lokalbot-cotabby-compare-20261002')
sys.path.insert(0,str(repo/'scripts'))
import phrase_eval as pe
workspace=repo/'build/cotabby-dependencies/Cotabby.xcworkspace'
source=next((pe.DERIVED/'Build/Products').glob('Cotabby_*.xctestrun'))
record={'sourceSHA256':pe.build_input_fingerprint(workspace),'productSHA256':pe.build_product_fingerprint(source),'xctestrun':str(source),'manualBuildLog':'/private/tmp/lokalbot-cotabby-build.log'}
(pe.DERIVED/'phrase-eval-build.json').write_text(json.dumps(record,indent=2)+'\n')
original_stage=pe.sign_test_hosts
original_retarget=pe.retarget_test_host
original_inject=pe.inject_environment
state={}
@contextlib.contextmanager
def isolated_stage(products,output):
 with original_stage(products,output) as host:
  fixture_home=host.parent/'home';fixture_home.mkdir()
  state['home']=str(fixture_home)
  identity='me.dotenv.cotabby-quality-'+uuid.uuid4().hex
  state['identity']=identity
  info=host/'Contents/Info.plist';data=plistlib.loads(info.read_bytes());data['CFBundleIdentifier']=identity;info.write_bytes(plistlib.dumps(data))
  pe.logged_command(['codesign','--force','--deep','--sign','-','--timestamp=none','--options','runtime','--entitlements',output/'test-host.entitlements',host],output/'isolation-sign.log')
  (output/'isolation.json').write_text(json.dumps({'bundleIdentifier':identity,'home':'temporary disposable directory','changes':'test-host identity and home only; production source unmodified'},indent=2)+'\n')
  yield host

def retarget(value,host):
 count=original_retarget(value,host)
 def walk(v):
  if isinstance(v,dict):
   if 'TestHostBundleIdentifier' in v:v['TestHostBundleIdentifier']=state['identity']
   for i in v.values():walk(i)
  elif isinstance(v,list):
   for i in v:walk(i)
 walk(value)
 return count

def inject(value,environment):
 return original_inject(value,dict(environment,CFFIXED_USER_HOME=state['home']))
pe.sign_test_hosts=isolated_stage;pe.retarget_test_host=retarget;pe.inject_environment=inject
pe.main()
